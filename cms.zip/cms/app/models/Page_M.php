<?php
/**
* 
*/
class Page_m extends My_Model
{
	protected $_table_name = "pages"; 
	protected $_primary_key = "id"; 
	protected $_primary_filter = "intval"; 
	protected $_order_by = "order"; 
	public  $_rules = array(); 
	protected $_timestamps = FALSE; 
	
	function __construct()
	{
	parent::__construct(); 
	}
}