<body class="login-body">

<div class="container">

<?php 
$attributes = array('class' => 'form-signin');

echo form_open('admin/user/login', $attributes); ?>
<div class="form-signin-heading text-center">
<h1 class="sign-title">Sign In</h1>
<img src="<?php echo base_url().'assets/admin/'?>images/login-logo.png" alt=""/>
</div>
<div class="login-wrap">
<?php  echo validation_errors('<div class="alert alert-danger" ><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>', '</strong></div>'); ?>
<!--  <div class="alert alert-success">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Success!</strong> Indicates a successful or positive action.
</div> -->
<?php 

if($this->session->flashdata('login_error1')){
	echo '<span style="color:red;font-size:bold;">'.$this->session->flashdata('login_error1').'</span>';
}

if($this->session->flashdata('login_error2')){
	echo '<span style="color:red;font-size:bold;">'.$this->session->flashdata('login_error2').'</span>';
}

if($this->session->flashdata('login_error3')){
	echo '<span style="color:red;font-size:bold;">'.$this->session->flashdata('login_error3').'</span>';
}
?>
<input type="text" name ="username" class="form-control" value="<?php echo set_value('username'); ?>" placeholder="Email Address Or Username" autofocus>
<input type="password" name ="password"  class="form-control" value="<?php echo set_value('password'); ?>" placeholder="Password">

<button class="btn btn-lg btn-login btn-block" type="submit">
<i class="fa fa-check"></i>
</button>


<label class="checkbox">
<input type="checkbox" value="remember-me"> Remember me
<span class="pull-right">
<a data-toggle="modal" href="#myModal"> Forgot Password?</a>

</span>
</label>

</div>

<!-- Modal -->
<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">Forgot Password ?</h4>
</div>
<div class="modal-body">
<p>Enter your e-mail address below to reset your password.</p>
<input type="text" name="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">

</div>
<div class="modal-footer">
<button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
<button class="btn btn-primary" type="button">Submit</button>
</div>
</div>
</div>
</div>
<!-- modal -->

</form>

</div>
