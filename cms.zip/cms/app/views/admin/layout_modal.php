<!DOCTYPE html>
<html lang="en">
<head>
<?php include ('templates/head.php');?>  
</head>

<?php $this->load->view($subview['subview']); ?>

<!-- Placed js at the end of the document so the pages load faster -->
<?php include 'templates/javascript.php';?>
</body>
</html>
