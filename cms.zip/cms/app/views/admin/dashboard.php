<!DOCTYPE html>
<html lang="en">
<head>
<?php include ('templates/head.php');?>  
</head>

<?php include 'dashboard_body.php';?>
</html>
