<body class="sticky-header">

<section>
    <!-- left side start-->
   <?php include ('templates/left_side.php');  ?>
    <!-- left side end-->

    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

        <!--toggle button start-->
        <a class="toggle-btn"><i class="fa fa-bars"></i></a>
        <!--toggle button end-->

        <!--search start-->
   <?php include ('templates/search.php');?>
        <!--search end-->

        <!--notification menu start -->
        <div class="menu-right">
        <?php include ('templates/notification.php');?>
        </div>
        <!--notification menu end -->

        </div>
        <!-- header section end-->

        <!-- page heading start-->
        <div class="page-heading">
          <?php include ('templates/breadcrumb.php');?>
        </div>
        <!-- page heading end-->

        <!--body wrapper start-->
        <div class="wrapper">
        

			
        </div>
        <!--body wrapper end-->

        <!--footer section start-->
        <footer>
            <?php include 'templates/footer.php';?> 
        </footer>
        <!--footer section end-->


    </div>
    <!-- main content end-->
</section>

<?php include 'templates/javascript.php';?>
</body>