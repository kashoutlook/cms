<!-- Placed js at the end of the document so the pages load faster -->
<script src="<?php echo base_url().'assets/admin/'?>js/jquery-1.10.2.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/modernizr.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/jquery.nicescroll.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/owl.carousel.js" ></script>
<!--ios7-->
<script src="<?php echo base_url().'assets/admin/'?>js/ios-switch/switchery.js" ></script>
<script src="<?php echo base_url().'assets/admin/'?>js/ios-switch/ios-init.js" ></script>

<!--icheck -->
<script src="<?php echo base_url().'assets/admin/'?>js/iCheck/jquery.icheck.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/icheck-init.js"></script>
<!--multi-select-->
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/jquery-multi-select/js/jquery.multi-select.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/jquery-multi-select/js/jquery.quicksearch.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/multi-select-init.js"></script>
<!--spinner-->
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/fuelux/js/spinner.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/spinner-init.js"></script>
<!--file upload-->
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-fileupload.min.js"></script>
<!--tags input-->
<script src="<?php echo base_url().'assets/admin/'?>js/jquery-tags-input/jquery.tagsinput.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/tagsinput-init.js"></script>
<!--bootstrap input mask-->
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>
<!--bootstrap editors-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />

<!--dynamic table-->
<script type="text/javascript" language="javascript" src="<?php echo base_url().'assets/admin/'?>js/advanced-datatable/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/data-tables/DT_bootstrap.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo base_url().'assets/admin/'?>js/dynamic_table_init.js"></script>

<!--Form validations -->
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/jquery.validate.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/validation-init.js"></script>

<!--isotope js -->
<script src="<?php echo base_url().'assets/admin/'?>js/jquery.isotope.js"></script>

<!--dropzone-->
<script src="<?php echo base_url().'assets/admin/'?>js/dropzone/dropzone.js"></script>

<!--stepy js -->
<script src="<?php echo base_url().'assets/admin/'?>js/jquery.stepy.js"></script>

<!--Editors js -->
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/ckeditor/ckeditor.js"></script>

<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/sample.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/ckeditor_self.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>

<!--pickers plugins-->
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/admin/'?>js/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>

<!--full calendar plugins-->
<script src="<?php echo base_url().'assets/admin/'?>js/fullcalendar/fullcalendar.min.js"></script>
<script src="<?php echo base_url().'assets/admin/'?>js/external-dragging-calendar.js"></script>

<!--pickers initialization-->
<script src="<?php echo base_url().'assets/admin/'?>js/pickers-init.js"></script>

<!--common scripts for all pages-->
<script src="<?php echo base_url().'assets/admin/'?>js/scripts.js"></script>

<script>


    $(document).ready(function() {

        $("#slide-img").owlCarousel({

            navigation : true, // Show next and prev buttons
            slideSpeed : 300,
            paginationSpeed : 400,
            singleItem:true,
            autoPlay:true

            // "singleItem:true" is a shortcut for:
            // items : 1,
            // itemsDesktop : false,
            // itemsDesktopSmall : false,
            // itemsTablet: false,
            // itemsMobile : false

        });

    });


</script>


<script>
    /*=====STEPY WIZARD====*/
    $(function() {
        $('#default').stepy({
            backLabel: 'Previous',
            block: true,
            nextLabel: 'Next',
            titleClick: true,
            titleTarget: '.stepy-tab'
        });
    });
    /*=====STEPY WIZARD WITH VALIDATION====*/
    $(function() {
        $('#stepy_form').stepy({
            backLabel: 'Back',
            nextLabel: 'Next',
            errorImage: true,
            block: true,
            description: true,
            legend: false,
            titleClick: true,
            titleTarget: '#top_tabby',
            validate: true
        });
        $('#stepy_form').validate({
            errorPlacement: function(error, element) {
                $('#stepy_form div.stepy-error').append(error);
            },
            rules: {
                'name': 'required',
                'email': 'required'
            },
            messages: {
                'name': {
                    required: 'Name field is required!'
                },
                'email': {
                    required: 'Email field is requerid!'
                }
            }
        });
    });
</script>

<script>
    jQuery(document).ready(function(){
         $('.wysihtml5').wysihtml5();
    });
</script>

<script type="text/javascript">
    $(function() {
        var $container = $('#gallery');
        $container.isotope({
            itemSelector: '.item',
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            }
        });

        // filter items when filter link is clicked
        $('#filters a').click(function() {
            var selector = $(this).attr('data-filter');
            $container.isotope({filter: selector});
            return false;
        });
    });
</script>

<script>
	initSample();
</script>
