 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="ThemeBucket">
  <link rel="shortcut icon" href="#" type="image/png">

  <title><?php echo $head_info['title']; ?></title>

    <!--ios7-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/ios-switch/switchery.css" />

    <!--icheck-->
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/minimal/minimal.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/minimal/red.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/minimal/green.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/minimal/blue.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/minimal/yellow.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/minimal/purple.css" rel="stylesheet">

    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/square/square.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/square/red.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/square/green.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/square/blue.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/square/yellow.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/square/purple.css" rel="stylesheet">

    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/flat/grey.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/flat/red.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/flat/green.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/flat/blue.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/flat/yellow.css" rel="stylesheet">
    <link href="<?php echo base_url().'assets/admin/'?>js/iCheck/skins/flat/purple.css" rel="stylesheet">

	  <!--pickers css-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/bootstrap-datepicker/css/datepicker-custom.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/bootstrap-timepicker/css/timepicker.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/bootstrap-colorpicker/css/colorpicker.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/bootstrap-daterangepicker/daterangepicker-bs3.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/bootstrap-datetimepicker/css/datetimepicker-custom.css" />
	
	  <!--calendar css-->
  <link href="<?php echo base_url().'assets/admin/'?>js/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	
    <!--multi-select-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/jquery-multi-select/css/multi-select.css" />

    <!--file upload-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>css/bootstrap-fileupload.min.css" />

    <!--tags input-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/admin/'?>js/jquery-tags-input/jquery.tagsinput.css" />

  <!--dropzone css-->
  <link href="<?php echo base_url().'assets/admin/'?>js/dropzone/css/dropzone.css" rel="stylesheet"/>

  <link href="<?php echo base_url().'assets/admin/'?>css/style.css" rel="stylesheet">
  <link href="<?php echo base_url().'assets/admin/'?>css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url().'assets/admin/'?>css/owl.carousel.css" type="text/css">
  <link rel="stylesheet" href="<?php echo base_url().'assets/admin/'?>css/owl.theme.css" type="text/css">
  
   <!--dynamic table-->
  <link href="<?php echo base_url().'assets/admin/'?>js/advanced-datatable/css/demo_page.css" rel="stylesheet" />
  <link href="<?php echo base_url().'assets/admin/'?>js/advanced-datatable/css/demo_table.css" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo base_url().'assets/admin/'?>js/data-tables/DT_bootstrap.css" />
  
  <!--stepy css-->
  <link href="<?php echo base_url().'assets/admin/'?>css/jquery.stepy.css" rel="stylesheet">
  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <script src="js/respond.min.js"></script>
  <![endif]-->