<!DOCTYPE html>
<html lang="en">
<head>
 <?php include('templates/head.php'); ?>
</head>

<body class="sticky-header">

<section>
    <!-- left side start-->
    <?php include 'templates/left_side.php';?>
     <!-- left side End-->

    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

        <!--toggle button start-->
        <a class="toggle-btn"><i class="fa fa-bars"></i></a>
        <!--toggle button end-->

        <!--search start-->
        <form class="searchform" action="index.html" method="post">
            <input type="text" class="form-control" name="keyword" placeholder="Search here..." />
        </form>
        <!--search end-->

        <!--notification menu start -->
        <div class="menu-right">
            <ul class="notification-menu">
                <li>
                    <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                        <i class="fa fa-tasks"></i>
                        <span class="badge">8</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-head pull-right">
                        <h5 class="title">You have 8 pending task</h5>
                        <ul class="dropdown-list user-list">
                            <li class="new">
                                <a href="#">
                                    <div class="task-info">
                                        <div>Database update</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-warning">
                                            <span class="">40%</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="new">
                                <a href="#">
                                    <div class="task-info">
                                        <div>Dashboard done</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div style="width: 90%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="90" role="progressbar" class="progress-bar progress-bar-success">
                                            <span class="">90%</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div>Web Development</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div style="width: 66%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="66" role="progressbar" class="progress-bar progress-bar-info">
                                            <span class="">66% </span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div>Mobile App</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div style="width: 33%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="33" role="progressbar" class="progress-bar progress-bar-danger">
                                            <span class="">33% </span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div>Issues fixed</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div style="width: 80%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="80" role="progressbar" class="progress-bar">
                                            <span class="">80% </span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="new"><a href="">See All Pending Task</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                        <i class="fa fa-envelope-o"></i>
                        <span class="badge">5</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-head pull-right">
                        <h5 class="title">You have 5 Mails </h5>
                        <ul class="dropdown-list normal-list">
                            <li class="new">
                                <a href="">
                                    <span class="thumb"><img src="images/photos/user1.png" alt="" /></span>
                                        <span class="desc">
                                          <span class="name">John Doe <span class="badge badge-success">new</span></span>
                                          <span class="msg">Lorem ipsum dolor sit amet...</span>
                                        </span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="thumb"><img src="images/photos/user2.png" alt="" /></span>
                                        <span class="desc">
                                          <span class="name">Jonathan Smith</span>
                                          <span class="msg">Lorem ipsum dolor sit amet...</span>
                                        </span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="thumb"><img src="images/photos/user3.png" alt="" /></span>
                                        <span class="desc">
                                          <span class="name">Jane Doe</span>
                                          <span class="msg">Lorem ipsum dolor sit amet...</span>
                                        </span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="thumb"><img src="images/photos/user4.png" alt="" /></span>
                                        <span class="desc">
                                          <span class="name">Mark Henry</span>
                                          <span class="msg">Lorem ipsum dolor sit amet...</span>
                                        </span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <span class="thumb"><img src="images/photos/user5.png" alt="" /></span>
                                        <span class="desc">
                                          <span class="name">Jim Doe</span>
                                          <span class="msg">Lorem ipsum dolor sit amet...</span>
                                        </span>
                                </a>
                            </li>
                            <li class="new"><a href="">Read All Mails</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                        <i class="fa fa-bell-o"></i>
                        <span class="badge">4</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-head pull-right">
                        <h5 class="title">Notifications</h5>
                        <ul class="dropdown-list normal-list">
                            <li class="new">
                                <a href="">
                                    <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                                    <span class="name">Server #1 overloaded.  </span>
                                    <em class="small">34 mins</em>
                                </a>
                            </li>
                            <li class="new">
                                <a href="">
                                    <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                                    <span class="name">Server #3 overloaded.  </span>
                                    <em class="small">1 hrs</em>
                                </a>
                            </li>
                            <li class="new">
                                <a href="">
                                    <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                                    <span class="name">Server #5 overloaded.  </span>
                                    <em class="small">4 hrs</em>
                                </a>
                            </li>
                            <li class="new">
                                <a href="">
                                    <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                                    <span class="name">Server #31 overloaded.  </span>
                                    <em class="small">4 hrs</em>
                                </a>
                            </li>
                            <li class="new"><a href="">See All Notifications</a></li>
                        </ul>
                    </div>
                </li>
                <li>
                    <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <img src="images/photos/user-avatar.png" alt="" />
                        John Doe
                        <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                        <li><a href="#"><i class="fa fa-user"></i>  Profile</a></li>
                        <li><a href="#"><i class="fa fa-cog"></i>  Settings</a></li>
                        <li><a href="#"><i class="fa fa-sign-out"></i> Log Out</a></li>
                    </ul>
                </li>

            </ul>
        </div>
        <!--notification menu end -->

        </div>
        <!-- header section end-->

        <!-- page heading start-->
        <div class="page-heading">
            <h3>
                Advanced Components
            </h3>
            <ul class="breadcrumb">
                <li>
                    <a href="#">Forms</a>
                </li>
                <li class="active"> Advanced Components </li>
            </ul>
        </div>
        <!-- page heading end-->

        <!--body wrapper start-->
        <div class="wrapper">
            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Slide Toggle
                        <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <div class="slide-toggle">
                                <div>
                                    <input type="checkbox" class="js-switch" checked/>
                                </div>
                                <div>
                                    <input type="checkbox" class="js-switch-blue" checked/>
                                </div>
                                <div>
                                    <input type="checkbox" class="js-switch-pink" checked/>
                                </div>
                                <div>
                                    <input type="checkbox" class="js-switch-teal" checked/>
                                </div>
                                <div>
                                    <input type="checkbox" class="js-switch-red" checked/>
                                </div>
                                <div>
                                    <input type="checkbox" class="js-switch-yellow" checked/>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Custom Checkbox & Radio
                        <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                    </header>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <form class="form-horizontal bucket-form" method="get">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Checkboxes</label>

                                        <div class="col-sm-9 icheck minimal">
                                            <div class="checkbox single-row">
                                                <input type="checkbox"  >
                                                <label>Checkbox 1</label>
                                            </div>

                                            <div class="checkbox single-row">
                                                <label class="disabled"><input type="checkbox" disabled="" checked="" ></label>
                                                <label>Disabled</label>
                                            </div>


                                            <div class="checkbox checked single-row">
                                                <label class="disabled"><input type="checkbox" disabled="" checked=" " id=""></label>
                                                <label>Checked &amp; Disabled</label>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-6">
                                <form class="form-horizontal bucket-form" method="get">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Radio</label>

                                        <div class="col-sm-9 icheck minimal">
                                            <div class="radio single-row">
                                                <input tabindex="3" type="radio"  name="demo-radio">
                                                <label>Checkbox 1</label>
                                            </div>

                                            <div class="radio single-row">
                                                <label class="disabled"><input type="radio" disabled="" ></label>
                                                <label>Disabled</label>
                                            </div>


                                            <div class="radio checked single-row">
                                                <label class=" disabled"><input type="radio" disabled="" checked=""></label>
                                                <label>Checked &amp; Disabled</label>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
            <div class="row">
                <div class="col-lg-12">
        <section class="panel">
        <header class="panel-heading">
            Different Color Custom Checkbox & Radio
            <span class="tools pull-right">
                <a class="fa fa-chevron-down" href="javascript:;"></a>
                <a class="fa fa-times" href="javascript:;"></a>
             </span>
        </header>
        <div class="panel-body">
        <div class="row">
            <div class="col-md-6">
                <form class="form-horizontal bucket-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Checkboxes</label>

                        <div class="col-sm-9 icheck ">

                            <div class="minimal single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Black Checkbox </label>
                                </div>
                            </div>
                            <div class="minimal-red single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Red Checkbox </label>
                                </div>
                            </div>

                            <div class="minimal-green single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Green Checkbox </label>
                                </div>
                            </div>

                            <div class="minimal-blue single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Blue Checkbox </label>
                                </div>
                            </div>

                            <div class="minimal-yellow single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Yellow Checkbox </label>
                                </div>
                            </div>

                            <div class="minimal-purple single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Purple Checkbox </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <form class="form-horizontal bucket-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Checkboxes</label>

                        <div class="col-sm-9 icheck ">

                            <div class="square single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Black Checkbox </label>
                                </div>
                            </div>
                            <div class="square-red single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Red Checkbox </label>
                                </div>
                            </div>

                            <div class="square-green single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Green Checkbox </label>
                                </div>
                            </div>

                            <div class="square-blue single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Blue Checkbox </label>
                                </div>
                            </div>

                            <div class="square-yellow single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Yellow Checkbox </label>
                                </div>
                            </div>

                            <div class="square-purple single-row">
                                <div class="checkbox ">
                                    <input type="checkbox" checked>
                                    <label>Purple Checkbox </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <br>
        <br>
        <div class="row">
            <div class="col-md-6">
                <form class="form-horizontal bucket-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Radio</label>

                        <div class="col-sm-9 icheck ">

                            <div class="minimal single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Black Radio </label>
                                </div>
                            </div>
                            <div class="minimal-red single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio" checked>
                                    <label>Red Radio </label>
                                </div>
                            </div>

                            <div class="minimal-green single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Green Radio </label>
                                </div>
                            </div>

                            <div class="minimal-blue single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Blue Radio </label>
                                </div>
                            </div>

                            <div class="minimal-yellow single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Yellow Radio </label>
                                </div>
                            </div>

                            <div class="minimal-purple single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Purple Radio </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <form class="form-horizontal bucket-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Radio</label>

                        <div class="col-sm-9 icheck ">

                            <div class="square single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Black Radio </label>
                                </div>
                            </div>
                            <div class="square-red single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio" >
                                    <label>Red Radio </label>
                                </div>
                            </div>

                            <div class="square-green single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Green Radio </label>
                                </div>
                            </div>

                            <div class="square-blue single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Blue Radio </label>
                                </div>
                            </div>

                            <div class="square-yellow single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Yellow Radio </label>
                                </div>
                            </div>

                            <div class="square-purple single-row">
                                <div class="radio ">
                                    <input tabindex="3" type="radio"  name="demo-radio">
                                    <label>Purple Radio </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        </div>
        </section>
        </div>
        </div>
            <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        flat checkbox & radio
                        <span class="tools pull-right">
                            <a class="fa fa-chevron-down" href="javascript:;"></a>
                            <a class="fa fa-times" href="javascript:;"></a>
                         </span>
                    </header>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <form class="form-horizontal bucket-form" method="get">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Checkbox</label>

                                        <div class="col-sm-9 icheck ">

                                            <div class="flat-grey single-row">
                                                <div class="radio ">
                                                    <input type="checkbox" checked>
                                                    <label>Black Checkbox </label>
                                                </div>
                                            </div>
                                            <div class="flat-red single-row">
                                                <div class="radio ">
                                                    <input type="checkbox" checked>
                                                    <label>Red Checkbox </label>
                                                </div>
                                            </div>

                                            <div class="flat-green single-row">
                                                <div class="radio ">
                                                    <input type="checkbox" checked>
                                                    <label>Green Checkbox </label>
                                                </div>
                                            </div>

                                            <div class="flat-blue single-row">
                                                <div class="radio ">
                                                    <input type="checkbox" checked>
                                                    <label>Blue Checkbox </label>
                                                </div>
                                            </div>

                                            <div class="flat-yellow single-row">
                                                <div class="radio ">
                                                    <input type="checkbox" checked>
                                                    <label>Yellow Checkbox </label>
                                                </div>
                                            </div>

                                            <div class="flat-purple single-row">
                                                <div class="radio ">
                                                    <input type="checkbox" checked>
                                                    <label>Purple Checkbox </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-6">
                                <form class="form-horizontal bucket-form" method="get">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Radio</label>

                                        <div class="col-sm-9 icheck ">

                                            <div class="flat-grey single-row">
                                                <div class="radio ">
                                                    <input tabindex="3" type="radio"  name="demo-radio" >
                                                    <label>Black Radio </label>
                                                </div>
                                            </div>
                                            <div class="flat-red single-row">
                                                <div class="radio ">
                                                    <input tabindex="3" type="radio"  name="demo-radio">
                                                    <label>Red Radio </label>
                                                </div>
                                            </div>

                                            <div class="flat-green single-row">
                                                <div class="radio ">
                                                    <input tabindex="3" type="radio"  name="demo-radio">
                                                    <label>Green Radio </label>
                                                </div>
                                            </div>

                                            <div class="flat-blue single-row">
                                                <div class="radio ">
                                                    <input tabindex="3" type="radio"  name="demo-radio">
                                                    <label>Blue Radio </label>
                                                </div>
                                            </div>

                                            <div class="flat-yellow single-row">
                                                <div class="radio ">
                                                    <input tabindex="3" type="radio"  name="demo-radio">
                                                    <label>Yellow Radio </label>
                                                </div>
                                            </div>

                                            <div class="flat-purple single-row">
                                                <div class="radio ">
                                                    <input tabindex="3" type="radio"  name="demo-radio">
                                                    <label>Purple Radio </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Multiple Select
                              <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                        <form action="#" class="form-horizontal ">
                            <div class="form-group">
                            <label class="control-label col-md-3">Default</label>

                            <div class="col-md-9">
                                <select multiple="multiple" class="multi-select" id="my_multi_select1"
                                        name="my_multi_select1[]">
                                    <option>Dallas Cowboys</option>
                                    <option>New York Giants</option>
                                    <option selected>Philadelphia Eagles</option>
                                    <option selected>Washington Redskins</option>
                                    <option>Chicago Bears</option>
                                    <option>Detroit Lions</option>
                                    <option>Green Bay Packers</option>
                                    <option>Minnesota Vikings</option>
                                    <option selected>Atlanta Falcons</option>
                                    <option>Carolina Panthers</option>
                                    <option>New Orleans Saints</option>
                                    <option>Tampa Bay Buccaneers</option>
                                    <option>Arizona Cardinals</option>
                                    <option>St. Louis Rams</option>
                                    <option>San Francisco 49ers</option>
                                    <option>Seattle Seahawks</option>
                                </select>
                            </div>
                        </div>
                            <div class="form-group">
                            <label class="control-label col-md-3">Grouped Options</label>

                            <div class="col-md-9">
                                <select multiple="multiple" class="multi-select" id="my_multi_select2"
                                        name="my_multi_select2[]">
                                    <optgroup label="NFC EAST">
                                        <option>Dallas Cowboys</option>
                                        <option>New York Giants</option>
                                        <option>Philadelphia Eagles</option>
                                        <option>Washington Redskins</option>
                                    </optgroup>
                                    <optgroup label="NFC NORTH">
                                        <option>Chicago Bears</option>
                                        <option>Detroit Lions</option>
                                        <option>Green Bay Packers</option>
                                        <option>Minnesota Vikings</option>
                                    </optgroup>
                                    <optgroup label="NFC SOUTH">
                                        <option>Atlanta Falcons</option>
                                        <option>Carolina Panthers</option>
                                        <option>New Orleans Saints</option>
                                        <option>Tampa Bay Buccaneers</option>
                                    </optgroup>
                                    <optgroup label="NFC WEST">
                                        <option>Arizona Cardinals</option>
                                        <option>St. Louis Rams</option>
                                        <option>San Francisco 49ers</option>
                                        <option>Seattle Seahawks</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                            <div class="form-group last">
                                <label class="control-label col-md-3">Searchable</label>

                                <div class="col-md-9">
                                <select name="country" class="multi-select" multiple="" id="my_multi_select3">
                            <option value="AF">Afghanistan</option>
                            <option value="AL">Albania</option>
                            <option value="DZ">Algeria</option>
                            <option value="AS">American Samoa</option>
                            <option value="AD">Andorra</option>
                            <option value="AO">Angola</option>
                            <option value="AI">Anguilla</option>
                            <option value="AQ">Antarctica</option>
                            <option value="AR">Argentina</option>
                            <option value="AM">Armenia</option>
                            <option value="AW">Aruba</option>
                            <option value="AU">Australia</option>
                            <option value="AT">Austria</option>
                            <option value="AZ">Azerbaijan</option>
                            <option value="BS">Bahamas</option>
                            <option value="BH">Bahrain</option>
                            <option value="BD">Bangladesh</option>
                            <option value="BB">Barbados</option>
                            <option value="BY">Belarus</option>
                            <option value="BE">Belgium</option>
                            <option value="BZ">Belize</option>
                            <option value="BJ">Benin</option>
                            <option value="BM">Bermuda</option>
                            <option value="BT">Bhutan</option>
                            <option value="BO">Bolivia</option>
                            <option value="BA">Bosnia and Herzegowina</option>
                            <option value="BW">Botswana</option>
                            <option value="BV">Bouvet Island</option>
                            <option value="BR">Brazil</option>
                            <option value="IO">British Indian Ocean Territory</option>
                            <option value="BN">Brunei Darussalam</option>
                            <option value="BG">Bulgaria</option>
                            <option value="BF">Burkina Faso</option>
                            <option value="BI">Burundi</option>
                            <option value="KH">Cambodia</option>
                            <option value="CM">Cameroon</option>
                            <option value="CA">Canada</option>
                            <option value="CV">Cape Verde</option>
                            <option value="KY">Cayman Islands</option>
                            <option value="CF">Central African Republic</option>
                            <option value="TD">Chad</option>
                            <option value="CL">Chile</option>
                            <option value="CN">China</option>
                            <option value="CX">Christmas Island</option>
                            <option value="CC">Cocos (Keeling) Islands</option>
                            <option value="CO">Colombia</option>
                            <option value="KM">Comoros</option>
                            <option value="CG">Congo</option>
                            <option value="CD">Congo, the Democratic Republic of the</option>
                            <option value="CK">Cook Islands</option>
                            <option value="CR">Costa Rica</option>
                            <option value="CI">Cote d'Ivoire</option>
                            <option value="HR">Croatia (Hrvatska)</option>
                            <option value="CU">Cuba</option>
                            <option value="CY">Cyprus</option>
                            <option value="CZ">Czech Republic</option>
                            <option value="DK">Denmark</option>
                            <option value="DJ">Djibouti</option>
                            <option value="DM">Dominica</option>
                            <option value="DO">Dominican Republic</option>
                            <option value="EC">Ecuador</option>
                            <option value="EG">Egypt</option>
                            <option value="SV">El Salvador</option>
                            <option value="GQ">Equatorial Guinea</option>
                            <option value="ER">Eritrea</option>
                            <option value="EE">Estonia</option>
                            <option value="ET">Ethiopia</option>
                            <option value="FK">Falkland Islands (Malvinas)</option>
                            <option value="FO">Faroe Islands</option>
                            <option value="FJ">Fiji</option>
                            <option value="FI">Finland</option>
                            <option value="FR">France</option>
                            <option value="GF">French Guiana</option>
                            <option value="PF">French Polynesia</option>
                            <option value="TF">French Southern Territories</option>
                            <option value="GA">Gabon</option>
                            <option value="GM">Gambia</option>
                            <option value="GE">Georgia</option>
                            <option value="DE">Germany</option>
                            <option value="GH">Ghana</option>
                            <option value="GI">Gibraltar</option>
                            <option value="GR">Greece</option>
                            <option value="GL">Greenland</option>
                            <option value="GD">Grenada</option>
                            <option value="GP">Guadeloupe</option>
                            <option value="GU">Guam</option>
                            <option value="GT">Guatemala</option>
                            <option value="GN">Guinea</option>
                            <option value="GW">Guinea-Bissau</option>
                            <option value="GY">Guyana</option>
                            <option value="HT">Haiti</option>
                            <option value="HM">Heard and Mc Donald Islands</option>
                            <option value="VA">Holy See (Vatican City State)</option>
                            <option value="HN">Honduras</option>
                            <option value="HK">Hong Kong</option>
                            <option value="HU">Hungary</option>
                            <option value="IS">Iceland</option>
                            <option value="IN">India</option>
                            <option value="ID">Indonesia</option>
                            <option value="IR">Iran (Islamic Republic of)</option>
                            <option value="IQ">Iraq</option>
                            <option value="IE">Ireland</option>
                            <option value="IL">Israel</option>
                            <option value="IT">Italy</option>
                            <option value="JM">Jamaica</option>
                            <option value="JP">Japan</option>
                            <option value="JO">Jordan</option>
                            <option value="KZ">Kazakhstan</option>
                            <option value="KE">Kenya</option>
                            <option value="KI">Kiribati</option>
                            <option value="KP">Korea, Democratic People's Republic of</option>
                            <option value="KR">Korea, Republic of</option>
                            <option value="KW">Kuwait</option>
                            <option value="KG">Kyrgyzstan</option>
                            <option value="LA">Lao People's Democratic Republic</option>
                            <option value="LV">Latvia</option>
                            <option value="LB">Lebanon</option>
                            <option value="LS">Lesotho</option>
                            <option value="LR">Liberia</option>
                            <option value="LY">Libyan Arab Jamahiriya</option>
                            <option value="LI">Liechtenstein</option>
                            <option value="LT">Lithuania</option>
                            <option value="LU">Luxembourg</option>
                            <option value="MO">Macau</option>
                            <option value="MK">Macedonia, The Former Yugoslav Republic of</option>
                            <option value="MG">Madagascar</option>
                            <option value="MW">Malawi</option>
                            <option value="MY">Malaysia</option>
                            <option value="MV">Maldives</option>
                            <option value="ML">Mali</option>
                            <option value="MT">Malta</option>
                            <option value="MH">Marshall Islands</option>
                            <option value="MQ">Martinique</option>
                            <option value="MR">Mauritania</option>
                            <option value="MU">Mauritius</option>
                            <option value="YT">Mayotte</option>
                            <option value="MX">Mexico</option>
                            <option value="FM">Micronesia, Federated States of</option>
                            <option value="MD">Moldova, Republic of</option>
                            <option value="MC">Monaco</option>
                            <option value="MN">Mongolia</option>
                            <option value="MS">Montserrat</option>
                            <option value="MA">Morocco</option>
                            <option value="MZ">Mozambique</option>
                            <option value="MM">Myanmar</option>
                            <option value="NA">Namibia</option>
                            <option value="NR">Nauru</option>
                            <option value="NP">Nepal</option>
                            <option value="NL">Netherlands</option>
                            <option value="AN">Netherlands Antilles</option>
                            <option value="NC">New Caledonia</option>
                            <option value="NZ">New Zealand</option>
                            <option value="NI">Nicaragua</option>
                            <option value="NE">Niger</option>
                            <option value="NG">Nigeria</option>
                            <option value="NU">Niue</option>
                            <option value="NF">Norfolk Island</option>
                            <option value="MP">Northern Mariana Islands</option>
                            <option value="NO">Norway</option>
                            <option value="OM">Oman</option>
                            <option value="PK">Pakistan</option>
                            <option value="PW">Palau</option>
                            <option value="PA">Panama</option>
                            <option value="PG">Papua New Guinea</option>
                            <option value="PY">Paraguay</option>
                            <option value="PE">Peru</option>
                            <option value="PH">Philippines</option>
                            <option value="PN">Pitcairn</option>
                            <option value="PL">Poland</option>
                            <option value="PT">Portugal</option>
                            <option value="PR">Puerto Rico</option>
                            <option value="QA">Qatar</option>
                            <option value="RE">Reunion</option>
                            <option value="RO">Romania</option>
                            <option value="RU">Russian Federation</option>
                            <option value="RW">Rwanda</option>
                            <option value="KN">Saint Kitts and Nevis</option>
                            <option value="LC">Saint LUCIA</option>
                            <option value="VC">Saint Vincent and the Grenadines</option>
                            <option value="WS">Samoa</option>
                            <option value="SM">San Marino</option>
                            <option value="ST">Sao Tome and Principe</option>
                            <option value="SA">Saudi Arabia</option>
                            <option value="SN">Senegal</option>
                            <option value="SC">Seychelles</option>
                            <option value="SL">Sierra Leone</option>
                            <option value="SG">Singapore</option>
                            <option value="SK">Slovakia (Slovak Republic)</option>
                            <option value="SI">Slovenia</option>
                            <option value="SB">Solomon Islands</option>
                            <option value="SO">Somalia</option>
                            <option value="ZA">South Africa</option>
                            <option value="GS">South Georgia and the South Sandwich Islands</option>
                            <option value="ES">Spain</option>
                            <option value="LK">Sri Lanka</option>
                            <option value="SH">St. Helena</option>
                            <option value="PM">St. Pierre and Miquelon</option>
                            <option value="SD">Sudan</option>
                            <option value="SR">Suriname</option>
                            <option value="SJ">Svalbard and Jan Mayen Islands</option>
                            <option value="SZ">Swaziland</option>
                            <option value="SE">Sweden</option>
                            <option value="CH">Switzerland</option>
                            <option value="SY">Syrian Arab Republic</option>
                            <option value="TW">Taiwan, Province of China</option>
                            <option value="TJ">Tajikistan</option>
                            <option value="TZ">Tanzania, United Republic of</option>
                            <option value="TH">Thailand</option>
                            <option value="TG">Togo</option>
                            <option value="TK">Tokelau</option>
                            <option value="TO">Tonga</option>
                            <option value="TT">Trinidad and Tobago</option>
                            <option value="TN">Tunisia</option>
                            <option value="TR">Turkey</option>
                            <option value="TM">Turkmenistan</option>
                            <option value="TC">Turks and Caicos Islands</option>
                            <option value="TV">Tuvalu</option>
                            <option value="UG">Uganda</option>
                            <option value="UA">Ukraine</option>
                            <option value="AE">United Arab Emirates</option>
                            <option value="GB">United Kingdom</option>
                            <option value="US">United States</option>
                            <option value="UM">United States Minor Outlying Islands</option>
                            <option value="UY">Uruguay</option>
                            <option value="UZ">Uzbekistan</option>
                            <option value="VU">Vanuatu</option>
                            <option value="VE">Venezuela</option>
                            <option value="VN">Viet Nam</option>
                            <option value="VG">Virgin Islands (British)</option>
                            <option value="VI">Virgin Islands (U.S.)</option>
                            <option value="WF">Wallis and Futuna Islands</option>
                            <option value="EH">Western Sahara</option>
                            <option value="YE">Yemen</option>
                            <option value="ZM">Zambia</option>
                            <option value="ZW">Zimbabwe</option>
                            </select>
                            </div>

                            </div>
                        </form>
                        </div>
                    </section>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Spinner
                         <span class="tools pull-right">
                            <a class="fa fa-chevron-down" href="javascript:;"></a>
                            <a class="fa fa-times" href="javascript:;"></a>
                         </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal ">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">Spinner 1</label>
                                            <div class="col-md-4">
                                                <div id="spinner1">
                                                    <div class="input-group input-small">
                                                        <input type="text" class="spinner-input form-control" maxlength="3" readonly>
                                                        <div class="spinner-buttons input-group-btn btn-group-vertical">
                                                            <button type="button" class="btn spinner-up btn-xs btn-default">
                                                                <i class="fa fa-angle-up"></i>
                                                            </button>
                                                            <button type="button" class="btn spinner-down btn-xs btn-default">
                                                                <i class="fa fa-angle-down"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                             <span class="help-block">
                                                basic example
                                             </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">Spinner 2</label>
                                            <div class="col-md-4">
                                                <div id="spinner2">
                                                    <div class="input-group input-small">
                                                        <input type="text" class="spinner-input form-control" maxlength="3" readonly>
                                                        <div class="spinner-buttons input-group-btn btn-group-vertical">
                                                            <button type="button" class="btn spinner-up btn-xs btn-info">
                                                                <i class="fa fa-angle-up"></i>
                                                            </button>
                                                            <button type="button" class="btn spinner-down btn-xs btn-info">
                                                                <i class="fa fa-angle-down"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                             <span class="help-block">
                                                disabled state
                                             </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label col-md-3">Spinner 3</label>
                                            <div class="col-md-9">
                                                <div id="spinner3">
                                                    <div class="input-group" style="width:150px;">
                                                        <input type="text" class="spinner-input form-control" maxlength="3" readonly>
                                                        <div class="spinner-buttons input-group-btn">
                                                            <button type="button" class="btn btn-default spinner-up">
                                                                <i class="fa fa-angle-up"></i>
                                                            </button>
                                                            <button type="button" class="btn btn-default spinner-down">
                                                                <i class="fa fa-angle-down"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                             <span class="help-block">
                                             with max value: 10
                                             </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group ">
                                            <label class="control-label col-md-3">Spinner 4</label>
                                            <div class="col-md-9">
                                                <div id="spinner4">
                                                    <div class="input-group" style="width:150px;">
                                                        <div class="spinner-buttons input-group-btn">
                                                            <button type="button" class="btn spinner-up btn-primary">
                                                                <i class="fa fa-plus"></i>
                                                            </button>
                                                        </div>
                                                        <input type="text" class="spinner-input form-control" maxlength="3" readonly>
                                                        <div class="spinner-buttons input-group-btn">
                                                            <button type="button" class="btn spinner-down btn-warning">
                                                                <i class="fa fa-minus"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                             <span class="help-block">
                                                with step: 5
                                             </span>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </form>
                        </div>
                    </section>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Advanced File Input
                          <span class="tools pull-right">
                            <a class="fa fa-chevron-down" href="javascript:;"></a>
                            <a class="fa fa-times" href="javascript:;"></a>
                         </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal ">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Default</label>
                                    <div class="col-md-4">
                                        <input type="file" class="default" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Without input</label>
                                    <div class="controls col-md-9">
                                        <div class="fileupload fileupload-new" data-provides="fileupload">
                                                <span class="btn btn-default btn-file">
                                                <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select file</span>
                                                <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                                <input type="file" class="default" />
                                                </span>
                                            <span class="fileupload-preview" style="margin-left:5px;"></span>
                                            <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left:5px;"></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group last">
                                    <label class="control-label col-md-3">Image Upload</label>
                                    <div class="col-md-9">
                                        <div class="fileupload fileupload-new" data-provides="fileupload">
                                            <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                                <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" />
                                            </div>
                                            <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                            <div>
                                                   <span class="btn btn-default btn-file">
                                                   <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select image</span>
                                                   <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                                   <input type="file" class="default" />
                                                   </span>
                                                <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload"><i class="fa fa-trash"></i> Remove</a>
                                            </div>
                                        </div>
                                        <br/>
                                        <span class="label label-danger ">NOTE!</span>
                                             <span>
                                             Attached image thumbnail is
                                             supported in Latest Firefox, Chrome, Opera,
                                             Safari and Internet Explorer 10 only
                                             </span>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </section>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Tags Input
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                            <a href="javascript:;" class="fa fa-times"></a>
                         </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class=" col-md-2 control-label">Default</label>
                                    <div class="col-md-10">
                                        <input id="tags_1" type="text" class="tags" value="php,ios,javascript,ruby,android,kindle" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-2 control-label">Fixed Width</label>
                                    <div class="col-md-10">
                                        <input id="tags_2" type="text" class="tags" value="tag1,tag2" />
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Masked inputs
                         <span class="tools pull-right">
                            <a class="fa fa-chevron-down" href="javascript:;"></a>
                            <a class="fa fa-times" href="javascript:;"></a>
                         </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">ISBN 1</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="999-99-999-9999-9" class="form-control">
                                        <span class="help-inline">999-99-999-9999-9</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">ISBN 2</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="999 99 999 9999 9" class="form-control">
                                        <span class="help-inline">999 99 999 9999 9</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">ISBN 3</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="999/99/999/9999/9" class="form-control">
                                        <span class="help-inline">999/99/999/9999/9</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">IPV4</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="999.999.999.9999" class="form-control">
                                        <span class="help-inline">192.168.110.310</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">IPV6</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="9999:9999:9999:9:999:9999:9999:9999" class="form-control">
                                        <span class="help-inline">4deg:1340:6547:2:540:h8je:ve73:98pd</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Tax ID</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="99-9999999" class="form-control">
                                        <span class="help-inline">99-9999999</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Phone</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="(999) 999-9999" class="form-control">
                                        <span class="help-inline">(999) 999-9999</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Currency</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="$ 999,999,999.99" class="form-control">
                                        <span class="help-inline">$ 999,999,999.99</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Date</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="99/99/9999" class="form-control">
                                        <span class="help-inline">dd/mm/yyyy</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Date 2</label>
                                    <div class="col-sm-10">
                                        <input type="text" placeholder="" data-mask="99-99-9999" class="form-control">
                                        <span class="help-inline">dd-mm-yyyy</span>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </section>
                </div>
            </div>

			
			<div class="row">
                <div class="col-md-12">
				WIDGETSSS
				   <div class="row">
                <div class="col-md-4">
                    <div class="panel widget-info-one">
                        <div class="avatar-img">
                            <img src="images/gallery/image3.jpg" alt=""/>
                        </div>
                        <div class="inner">
                            <div class="avatar"><img alt="" src="images/photos/userprofile.png"></div>
                            <h5>Margarita Rose</h5>
                            <span class="subtitle">
                                Praesent magna nunc, tincidunt pretium consequat dapibus.
                            </span>
                        </div>
                        <div class="panel-footer">
                            <ul class="post-view">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    109
                                </li>
                                <li class="active">
                                    <a href="#">
                                        <i class="fa fa-comment"></i>
                                    </a>
                                    233
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-heart"></i>
                                    </a>
                                    34
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel widget-info-twt blue-box">
                                <h5>Jonathan Smith</h5>
                                <span class="subtitle">Antepreneur</span>

                                <div class="avatar"><img alt="" src="images/photos/user1.png"></div>
                                <div class="followers">
                                    <span>434 Tweets</span> |
                                    <span>233 Following</span> |
                                    <span>45 followers</span>
                                </div>
                                <a class="btn btn-follow" href="#"><span><i></i>Follow</span></a>
                            </div>

                        </div>
                        <div class="col-md-12">
                            <div class="panel">
                                <ul class="iconic-list">
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-heart"></i>
                                        </a>
                                    </li>
                                    <li class="active">
                                        <a href="#">
                                            <i class="fa fa-camera-retro"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-calendar"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="last">
                                            <i class="fa fa-crosshairs"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="wdgt-profile">
                        <div class="profile">
                            <img src="images/gallery/wdgt-img.jpg" alt=""/>
                            <div class="profile-social">
                                <a href="#" ><i class="fa fa-pinterest"></i></a>
                                <a href="#" ><i class="fa fa-twitter"></i></a>
                                <a href="#" ><i class="fa fa-facebook"></i></a>
                            </div>
                            <ul class="profile-tab">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-camera"></i>
                                        Photo
                                    </a>
                                </li>
                                <li class="active">
                                    <a href="#">
                                        <i class="fa fa-user"></i>
                                        Profile
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-music"></i>
                                        Music
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-comments"></i>
                                        Comments
                                    </a>
                                </li>
                            </ul>

                        </div>
                        <div class="profile-info">
                            <h5>Margarita Rose</h5>
                            <span>Creative Designer</span>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row states-info">
                <div class="col-md-3">
                    <div class="panel red-bg">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-money"></i>
                                </div>
                                <div class="col-xs-8">
                                    <span class="state-title"> Dollar Profit Today </span>
                                    <h4>$ 23,232</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel blue-bg">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-tag"></i>
                                </div>
                                <div class="col-xs-8">
                                    <span class="state-title">  Copy Sold Today  </span>
                                    <h4>$ 2,980</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel green-bg">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-gavel"></i>
                                </div>
                                <div class="col-xs-8">
                                    <span class="state-title">  New Order  </span>
                                    <h4>5980</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel yellow-bg">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-eye"></i>
                                </div>
                                <div class="col-xs-8">
                                    <span class="state-title">  Unique Visitors  </span>
                                    <h4>10,000</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <section class="panel post-wrap pro-box">
                        <aside class="post-highlight purple v-align">
                            <div class="panel-body">
                                <h2>AdminEx in Excelent templates <a href="javascript:;"> http://themebucket.net/</a> 1 days ago  by John Doe</h2>
                            </div>
                        </aside>
                        <aside>
                            <div class="post-info">
                                <span class="arrow-pro left"></span>
                                <div class="panel-body">
                                    <div class="text-center twite">
                                        <i class="fa fa-twitter"></i>
                                        <h1>Twitter Feed</h1>
                                    </div>
                                </div>
                            </div>
                        </aside>
                    </section>
                </div>
                <div class="col-md-4">
                    <div id="slide-img" class="owl-carousel owl-theme">
                        <div class="item"><img src="images/gallery/image2.jpg" alt=""></div>
                        <div class="item"><img src="images/gallery/image3.jpg" alt=""></div>
                        <div class="item"><img src="images/gallery/image4.jpg" alt=""></div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-5">
                    <div class="panel  weather-info">
                        <div class="turquoise-bg white-text top-radius">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="text-center">
                                            <i class="big-icon  ico-cloudy"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="text-center">
                                            <div class="degree">47</div>
                                            <div>Very Hot Cloudy</div>
                                            <div class="d-value"><span>32</span> / <span>17</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="weather-location dark-turquoise-bg">
                            <form role="form" class="form-horizontal">
                                <div class="form-group">
                                    <div class="col-lg-12">
                                        <input type="text" placeholder="Find Location" class="form-control find-loc">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="panel-body">
                            <ul class="weather-forecast ">
                                <li class="first"><a id="su" href="javascript:;" ><strong>su</strong><span><i class="ico-cloudy"></i></span><span class="d-value">31</span></a></li>
                                <li><a id="mo" href="javascript:;" ><strong>mo</strong><span><i class=" ico-rainy2"></i></span><span class="d-value">20</span></a></li>
                                <li><a class="active" id="tu" href="javascript:;" ><strong>tu</strong><span><i class=" ico-lightning3"></i></span><span class="d-value">27</span></a></li>
                                <li><a id="we" href="javascript:;" ><strong>we</strong><span><i class=" ico-sun3"></i></span><span class="d-value">23</span></a></li>
                                <li><a id="th" href="javascript:;" ><strong>th</strong><span><i class=" ico-snowy3"></i></span><span class="d-value">26</span></a></li>
                                <li><a id="fr" href="javascript:;" ><strong>fr</strong><span><i class=" ico-cloudy "></i></span><span class="d-value">32</span></a></li>
                                <li class="last"><a id="sa" href="javascript:;" ><strong>sa</strong><span><i class=" ico-lightning3 "></i></span><span class="d-value">24</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel">
                        <div class="panel-body">
                            <div class="media usr-info">
                                <a class="pull-left" href="#">
                                    <img alt="" src="images/photos/user2.png" class="thumb">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading">Mila Watson</h4>
                                    <span>Senior UI Designer</span>
                                    <p>I use to design websites and applications for the web.</p>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer custom-trq-footer">
                            <ul class="user-states">
                                <li>
                                    <i class="fa fa-heart"></i> 127
                                </li>
                                <li>
                                    <i class="fa fa-eye"></i> 853
                                </li>
                                <li>
                                    <i class="fa fa-user"></i> 311
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="state-overview custom-s-view">
                        <div class="panel red ">
                            <div class="symbol s-icon text-center">
                                <i class="fa fa-eye"></i>
                            </div>
                            <div class="state-value">
                                <div class="value">390</div>
                                <div class="title"> Unique Visitors</div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-3">
                    <div class="panel">
                        <div class="panel-body">
                            <div class="dir-info">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <div class="avatar">
                                            <img src="images/photos/user2.png" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-xs-6">
                                        <h5>Wild Awake</h5>
                                        <span>
                                            <a href="#" class="small"> katy Perry</a>
                                        </span>
                                    </div>
                                    <div class="col-xs-3">
                                        <a class="dir-like" href="#">
                                            <span class="small">434</span>
                                            <i class="fa fa-heart"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-3">
                                        <div class="avatar">
                                            <img src="images/photos/user1.png" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-xs-6">
                                        <h5>Bulet Proof</h5>
                                        <span>
                                            <a href="#" class="small"> Bruno Mars</a>
                                        </span>
                                    </div>
                                    <div class="col-xs-3">
                                        <a class="dir-like" href="#">
                                            <span class="small">44</span>
                                            <i class="fa fa-heart"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-3">
                                        <div class="avatar">
                                            <img src="images/photos/user3.png" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-xs-6">
                                        <h5>Bit it</h5>
                                        <span>
                                            <a href="#" class="small"> Jackson</a>
                                        </span>
                                    </div>
                                    <div class="col-xs-3">
                                        <a class="dir-like" href="#">
                                            <span class="small">124</span>
                                            <i class="fa fa-heart"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-3">
                                        <div class="avatar">
                                            <img src="images/photos/user4.png" alt=""/>
                                        </div>
                                    </div>
                                    <div class="col-xs-6">
                                        <h5>Its my life</h5>
                                        <span>
                                            <a href="#" class="small"> Bon jovi</a>
                                        </span>
                                    </div>
                                    <div class="col-xs-3">
                                        <a class="dir-like" href="#">
                                            <span class="small">334</span>
                                            <i class="fa fa-heart"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
				
				</div>
			</div>
			
			Dynamic Table 
			 <div class="row">
        <div class="col-sm-12">
        <section class="panel">
        <header class="panel-heading">
            Dynamic Table
            <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
        </header>
        <div class="panel-body">
        <div class="adv-table">
        <table  class="display table table-bordered table-striped" id="dynamic-table">
        <thead>
        <tr>
            <th>Rendering engine</th>
            <th>Browser</th>
            <th>Platform(s)</th>
            <th class="hidden-phone">Engine version</th>
            <th class="hidden-phone">CSS grade</th>
        </tr>
        </thead>
        <tbody>
        <tr class="gradeX">
            <td>Trident</td>
            <td>Internet
                Explorer 4.0</td>
            <td>Win 95+</td>
            <td class="center hidden-phone">4</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeC">
            <td>Trident</td>
            <td>Internet
                Explorer 5.0</td>
            <td>Win 95+</td>
            <td class="center hidden-phone">5</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>Internet
                Explorer 5.5</td>
            <td>Win 95+</td>
            <td class="center hidden-phone">5.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>Internet
                Explorer 6</td>
            <td>Win 98+</td>
            <td class="center hidden-phone">6</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>Internet Explorer 7</td>
            <td>Win XP SP2+</td>
            <td class="center hidden-phone">7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>AOL browser (AOL desktop)</td>
            <td>Win XP</td>
            <td class="center hidden-phone">6</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 1.0</td>
            <td>Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 1.5</td>
            <td>Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 2.0</td>
            <td>Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 3.0</td>
            <td>Win 2k+ / OSX.3+</td>
            <td class="center hidden-phone">1.9</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Camino 1.0</td>
            <td>OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Camino 1.5</td>
            <td>OSX.3+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Netscape 7.2</td>
            <td>Win 95+ / Mac OS 8.6-9.2</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Netscape Browser 8</td>
            <td>Win 98SE+</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Netscape Navigator 9</td>
            <td>Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.0</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.1</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.2</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.2</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.3</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.3</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.4</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.4</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.5</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.6</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.6</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.7</td>
            <td>Win 98+ / OSX.1+</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.8</td>
            <td>Win 98+ / OSX.1+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Seamonkey 1.1</td>
            <td>Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Epiphany 2.20</td>
            <td>Gnome</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 1.2</td>
            <td>OSX.3</td>
            <td class="center hidden-phone">125.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 1.3</td>
            <td>OSX.3</td>
            <td class="center hidden-phone">312.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 2.0</td>
            <td>OSX.4+</td>
            <td class="center hidden-phone">419.3</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 3.0</td>
            <td>OSX.4+</td>
            <td class="center hidden-phone">522.1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>OmniWeb 5.5</td>
            <td>OSX.4+</td>
            <td class="center hidden-phone">420</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>iPod Touch / iPhone</td>
            <td>iPod</td>
            <td class="center hidden-phone">420.1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>S60</td>
            <td>S60</td>
            <td class="center hidden-phone">413</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 7.0</td>
            <td>Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 7.5</td>
            <td>Win 95+ / OSX.2+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 8.0</td>
            <td>Win 95+ / OSX.2+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 8.5</td>
            <td>Win 95+ / OSX.2+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 9.0</td>
            <td>Win 95+ / OSX.3+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 9.2</td>
            <td>Win 88+ / OSX.3+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 9.5</td>
            <td>Win 88+ / OSX.3+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera for Wii</td>
            <td>Wii</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Nokia N800</td>
            <td>N800</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Nintendo DS browser</td>
            <td>Nintendo DS</td>
            <td class="center hidden-phone">8.5</td>
            <td class="center hidden-phone">C/A<sup>1</sup></td>
        </tr>
        <tr class="gradeC">
            <td>KHTML</td>
            <td>Konqureror 3.1</td>
            <td>KDE 3.1</td>
            <td class="center hidden-phone">3.1</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeA">
            <td>KHTML</td>
            <td>Konqureror 3.3</td>
            <td>KDE 3.3</td>
            <td class="center hidden-phone">3.3</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>KHTML</td>
            <td>Konqureror 3.5</td>
            <td>KDE 3.5</td>
            <td class="center hidden-phone">3.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeX">
            <td>Tasman</td>
            <td>Internet Explorer 4.5</td>
            <td>Mac OS 8-9</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeC">
            <td>Tasman</td>
            <td>Internet Explorer 5.1</td>
            <td>Mac OS 7.6-9</td>
            <td class="center hidden-phone">1</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeC">
            <td>Tasman</td>
            <td>Internet Explorer 5.2</td>
            <td>Mac OS 8-X</td>
            <td class="center hidden-phone">1</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeA">
            <td>Misc</td>
            <td>NetFront 3.1</td>
            <td>Embedded devices</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeA">
            <td>Misc</td>
            <td>NetFront 3.4</td>
            <td>Embedded devices</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeX">
            <td>Misc</td>
            <td>Dillo 0.8</td>
            <td>Embedded devices</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeX">
            <td>Misc</td>
            <td>Links</td>
            <td>Text only</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeX">
            <td>Misc</td>
            <td>Lynx</td>
            <td>Text only</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeC">
            <td>Misc</td>
            <td>IE Mobile</td>
            <td>Windows Mobile 6</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeC">
            <td>Misc</td>
            <td>PSP browser</td>
            <td>PSP</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeU">
            <td>Other browsers</td>
            <td>All others</td>
            <td>-</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">U</td>
        </tr>
        </tbody>
        <tfoot>
        <tr>
            <th>Rendering engine</th>
            <th>Browser</th>
            <th>Platform(s)</th>
            <th class="hidden-phone">Engine version</th>
            <th class="hidden-phone">CSS grade</th>
        </tr>
        </tfoot>
        </table>
        </div>
        </div>
        </section>
        </div>
        </div>
        <div class="row">
        <div class="col-sm-12">
        <section class="panel">
        <header class="panel-heading">
            DataTables hidden row details example
            <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
        </header>
        <div class="panel-body">
        <div class="adv-table">
        <table class="display table table-bordered" id="hidden-table-info">
        <thead>
        <tr>
            <th>Rendering engine</th>
            <th>Browser</th>
            <th class="hidden-phone">Platform(s)</th>
            <th class="hidden-phone">Engine version</th>
            <th class="hidden-phone">CSS grade</th>
        </tr>
        </thead>
        <tbody>
        <tr class="gradeX">
            <td>Trident</td>
            <td>Internet
                Explorer 4.0</td>
            <td class="hidden-phone">Win 95+</td>
            <td class="center hidden-phone">4</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeC">
            <td>Trident</td>
            <td>Internet
                Explorer 5.0</td>
            <td class="hidden-phone">Win 95+</td>
            <td class="center hidden-phone">5</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>Internet
                Explorer 5.5</td>
            <td class="hidden-phone">Win 95+</td>
            <td class="center hidden-phone">5.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>Internet
                Explorer 6</td>
            <td class="hidden-phone">Win 98+</td>
            <td class="center hidden-phone">6</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>Internet Explorer 7</td>
            <td class="hidden-phone">Win XP SP2+</td>
            <td class="center hidden-phone">7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Trident</td>
            <td>AOL browser (AOL desktop)</td>
            <td class="hidden-phone">Win XP</td>
            <td class="center hidden-phone">6</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 1.0</td>
            <td class="hidden-phone">Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 1.5</td>
            <td class="hidden-phone">Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 2.0</td>
            <td class="hidden-phone">Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Firefox 3.0</td>
            <td class="hidden-phone">Win 2k+ / OSX.3+</td>
            <td class="center hidden-phone">1.9</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Camino 1.0</td>
            <td class="hidden-phone">OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Camino 1.5</td>
            <td class="hidden-phone">OSX.3+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Netscape 7.2</td>
            <td class="hidden-phone">Win 95+ / Mac OS 8.6-9.2</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Netscape Browser 8</td>
            <td class="hidden-phone">Win 98SE+</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Netscape Navigator 9</td>
            <td class="hidden-phone">Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.0</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.1</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.2</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.2</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.3</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.3</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.4</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.4</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.5</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.6</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">1.6</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.7</td>
            <td class="hidden-phone">Win 98+ / OSX.1+</td>
            <td class="center hidden-phone">1.7</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Mozilla 1.8</td>
            <td class="hidden-phone">Win 98+ / OSX.1+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Seamonkey 1.1</td>
            <td class="hidden-phone">Win 98+ / OSX.2+</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Gecko</td>
            <td>Epiphany 2.20</td>
            <td class="hidden-phone">Gnome</td>
            <td class="center hidden-phone">1.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 1.2</td>
            <td class="hidden-phone">OSX.3</td>
            <td class="center hidden-phone">125.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 1.3</td>
            <td class="hidden-phone">OSX.3</td>
            <td class="center hidden-phone">312.8</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 2.0</td>
            <td class="hidden-phone">OSX.4+</td>
            <td class="center hidden-phone">419.3</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>Safari 3.0</td>
            <td class="hidden-phone">OSX.4+</td>
            <td class="center hidden-phone">522.1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>OmniWeb 5.5</td>
            <td class="hidden-phone">OSX.4+</td>
            <td class="center hidden-phone">420</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>iPod Touch / iPhone</td>
            <td class="hidden-phone">iPod</td>
            <td class="center hidden-phone">420.1</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Webkit</td>
            <td>S60</td>
            <td class="hidden-phone">S60</td>
            <td class="center hidden-phone">413</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 7.0</td>
            <td class="hidden-phone">Win 95+ / OSX.1+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 7.5</td>
            <td class="hidden-phone">Win 95+ / OSX.2+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 8.0</td>
            <td class="hidden-phone">Win 95+ / OSX.2+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 8.5</td>
            <td class="hidden-phone">Win 95+ / OSX.2+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 9.0</td>
            <td class="hidden-phone">Win 95+ / OSX.3+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 9.2</td>
            <td class="hidden-phone">Win 88+ / OSX.3+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera 9.5</td>
            <td class="hidden-phone">Win 88+ / OSX.3+</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Opera for Wii</td>
            <td class="hidden-phone">Wii</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Nokia N800</td>
            <td class="hidden-phone">N800</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>Presto</td>
            <td>Nintendo DS browser</td>
            <td class="hidden-phone">Nintendo DS</td>
            <td class="center hidden-phone">8.5</td>
            <td class="center hidden-phone">C/A<sup>1</sup></td>
        </tr>
        <tr class="gradeC">
            <td>KHTML</td>
            <td>Konqureror 3.1</td>
            <td class="hidden-phone">KDE 3.1</td>
            <td class="center hidden-phone">3.1</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeA">
            <td>KHTML</td>
            <td>Konqureror 3.3</td>
            <td class="hidden-phone">KDE 3.3</td>
            <td class="center hidden-phone">3.3</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeA">
            <td>KHTML</td>
            <td>Konqureror 3.5</td>
            <td class="hidden-phone">KDE 3.5</td>
            <td class="center hidden-phone">3.5</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeX">
            <td>Tasman</td>
            <td>Internet Explorer 4.5</td>
            <td class="hidden-phone">Mac OS 8-9</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeC">
            <td>Tasman</td>
            <td>Internet Explorer 5.1</td>
            <td class="hidden-phone">Mac OS 7.6-9</td>
            <td class="center hidden-phone">1</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeC">
            <td>Tasman</td>
            <td>Internet Explorer 5.2</td>
            <td class="hidden-phone">Mac OS 8-X</td>
            <td class="center hidden-phone">1</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeA">
            <td>Misc</td>
            <td>NetFront 3.1</td>
            <td>Embedded devices</td>
            <td class="center">-</td>
            <td class="center">C</td>
        </tr>
        <tr class="gradeA">
            <td>Misc</td>
            <td>NetFront 3.4</td>
            <td class="hidden-phone">Embedded devices</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">A</td>
        </tr>
        <tr class="gradeX">
            <td>Misc</td>
            <td>Dillo 0.8</td>
            <td class="hidden-phone">Embedded devices</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeX">
            <td>Misc</td>
            <td>Links</td>
            <td class="hidden-phone">Text only</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeX">
            <td>Misc</td>
            <td>Lynx</td>
            <td class="hidden-phone">Text only</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">X</td>
        </tr>
        <tr class="gradeC">
            <td>Misc</td>
            <td>IE Mobile</td>
            <td class="hidden-phone">Windows Mobile 6</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeC">
            <td>Misc</td>
            <td>PSP browser</td>
            <td class="hidden-phone">PSP</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">C</td>
        </tr>
        <tr class="gradeU">
            <td>Other browsers</td>
            <td>All others</td>
            <td class="hidden-phone">-</td>
            <td class="center hidden-phone">-</td>
            <td class="center hidden-phone">U</td>
        </tr>
        </tbody>
        </table>

        </div>
        </div>
        </section>
        </div>
        </div>
			
			<h1>FORM LAYOUTS</h1>
			   <div class="row">
            <div class="col-lg-6">
                <section class="panel">
                    <header class="panel-heading">
                        Basic Forms
                    </header>
                    <div class="panel-body">
                        <form role="form">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputFile">File input</label>
                                <input type="file" id="exampleInputFile">
                                <p class="help-block">Example block-level help text here.</p>
                            </div>
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"> Check me out
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>

                    </div>
                </section>
            </div>
            <div class="col-lg-6">
                <section class="panel">
                    <header class="panel-heading">
                        Horizontal Forms
                    </header>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form">
                            <div class="form-group">
                                <label for="inputEmail1" class="col-lg-2 col-sm-2 control-label">Email</label>
                                <div class="col-lg-10">
                                    <input type="email" class="form-control" id="inputEmail1" placeholder="Email">
                                    <p class="help-block">Example block-level help text here.</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword1" class="col-lg-2 col-sm-2 control-label">Password</label>
                                <div class="col-lg-10">
                                    <input type="password" class="form-control" id="inputPassword1" placeholder="Password">
                                    <!--<p class="help-block">Example block-level help text here.</p>-->
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputFile2" class="col-lg-2 col-sm-2 control-label">File input</label>
                                <div class="col-lg-10">
                                <input type="file" id="exampleInputFile2">
                                <p class="help-block">Example block-level help text here.</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox"> Remember me
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-primary">Sign in</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>

            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Inline form
                    </header>
                    <div class="panel-body">
                        <form class="form-inline" role="form">
                            <div class="form-group">
                                <label class="sr-only" for="exampleInputEmail2">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Enter email">
                            </div>
                            <div class="form-group">
                                <label class="sr-only" for="exampleInputPassword2">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword2" placeholder="Password">
                            </div>
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"> Remember me
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary">Sign in</button>
                        </form>

                    </div>
                </section>

            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">

                    <div class="panel-body">
                        <a href="#myModal" data-toggle="modal" class="btn btn-xs btn-info">
                            Form in Modal
                        </a>
                        <a href="#myModal-1" data-toggle="modal" class="btn btn-xs btn-success">
                            Form in Modal 2
                        </a>
                        <a href="#myModal-2" data-toggle="modal" class="btn btn-xs btn-warning">
                            Form in Modal 3
                        </a>

                        <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                                        <h4 class="modal-title">Form Tittle</h4>
                                    </div>
                                    <div class="modal-body">

                                        <form role="form">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Enter email">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Password</label>
                                                <input type="password" class="form-control" id="exampleInputPassword3" placeholder="Password">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputFile">File input</label>
                                                <input type="file" id="exampleInputFile3">
                                                <p class="help-block">Example block-level help text here.</p>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox"> Check me out
                                                </label>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal-1" class="modal fade">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                                        <h4 class="modal-title">Form Tittle</h4>
                                    </div>
                                    <div class="modal-body">

                                        <form class="form-horizontal" role="form">
                                            <div class="form-group">
                                                <label for="inputEmail1" class="col-lg-2 col-sm-2 control-label">Email</label>
                                                <div class="col-lg-10">
                                                    <input type="email" class="form-control" id="inputEmail4" placeholder="Email">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputPassword1" class="col-lg-2 col-sm-2 control-label">Password</label>
                                                <div class="col-lg-10">
                                                    <input type="password" class="form-control" id="inputPassword4" placeholder="Password">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-lg-offset-2 col-lg-10">
                                                    <div class="checkbox">
                                                        <label>
                                                            <input type="checkbox"> Remember me
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-lg-offset-2 col-lg-10">
                                                    <button type="submit" class="btn btn-primary">Sign in</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>

                                </div>
                            </div>
                        </div>
                        <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal-2" class="modal fade">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                                        <h4 class="modal-title">Form Tittle</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form class="form-inline" role="form">
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputEmail2">Email address</label>
                                                <input type="email" class="form-control sm-input" id="exampleInputEmail5" placeholder="Enter email">
                                            </div>
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword2">Password</label>
                                                <input type="password" class="form-control sm-input" id="exampleInputPassword5" placeholder="Password">
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox"> Remember me
                                                </label>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Sign in</button>
                                        </form>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <section class="panel">
                    <header class="panel-heading">
                        Iconic field
                    </header>
                    <div class="panel-body">
                        <form role="form">
                            <div class="form-group">
                                <label>Left Icon</label>
                                <div class="iconic-input">
                                    <i class="fa fa-home"></i>
                                    <input type="text" class="form-control" placeholder="left icon">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Right Icon</label>
                                <div class="iconic-input right">
                                    <i class="fa fa-book"></i>
                                    <input type="text" class="form-control" placeholder="left icon">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Input with Loading</label>
                                <input type="text" class="form-control spinner" placeholder="Something Processing">
                            </div>

                        </form>

                    </div>
                </section>
            </div>
            <div class="col-lg-6">
                <section class="panel">
                    <header class="panel-heading">
                        Horizontal Iconic Forms
                    </header>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form">
                            <div class="form-group">
                                <label  class="col-lg-3 col-sm-3 control-label">Left Icon</label>
                                <div class="col-lg-9">
                                    <div class="iconic-input">
                                        <i class="fa fa-home"></i>
                                        <input type="text" class="form-control" placeholder="left icon">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label  class="col-lg-3 col-sm-3 control-label">Right Icon</label>
                                <div class="col-lg-9">
                                    <div class="iconic-input right">
                                        <i class="fa fa-lock"></i>
                                        <input type="text" class="form-control" placeholder="right icon">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label  class="col-lg-3 col-sm-3 control-label">Input with Loading</label>
                                <div class="col-lg-9">
                                    <div class="iconic-input right">
                                        <input type="text" class="form-control spinner" placeholder="Something Processing">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label col-lg-3">Button addons</label>
                                <div class="col-lg-9">
                                    <div class="input-group m-bot15">
                                              <span class="input-group-btn">
                                                <button type="button" class="btn btn-default"><i class="fa fa-search"></i></button>
                                              </span>
                                        <input type="text" class="form-control">
                                    </div>

                                </div>
                            </div>

                        </form>
                    </div>
                </section>
            </div>
        </div>
        <div class="row">
        <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Form Elements
            </header>
            <div class="panel-body">
                <form class="form-horizontal adminex-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Default</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Help text</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control">
                            <span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Rounder</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control round-input">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Input Tooltip</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Hover me" data-original-title="Tooltip goes here">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Input Popover</label>
                        <div class="col-sm-10">
                            <input type="text" data-trigger="click" data-content="Content goes here..." data-original-title="The Title" data-placement="top" data-toggle="popover" class="form-control popovers" placeholder="Click Me">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Input focus</label>
                        <div class="col-sm-10">
                            <input class="form-control" id="focusedInput" type="text" value="This is focused...">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Disabled</label>
                        <div class="col-sm-10">
                            <input class="form-control" id="disabledInput" type="text" placeholder="Disabled input here..." disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Placeholder</label>
                        <div class="col-sm-10">
                            <input type="text"  class="form-control" placeholder="placeholder">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 col-sm-2 control-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password"  class="form-control" placeholder="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 col-sm-2 control-label">Static control</label>
                        <div class="col-lg-10">
                            <p class="form-control-static">email@example.com</p>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <section class="panel">
            <div class="panel-body">
                <form class="form-horizontal adminex-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" for="inputSuccess">Control sizing</label>
                        <div class="col-lg-10">
                            <input class="form-control input-lg m-bot15" type="text" placeholder=".input-lg">
                            <input class="form-control m-bot15" type="text" placeholder="Default input">
                            <input class="form-control input-sm m-bot15" type="text" placeholder=".input-sm">

                            <select class="form-control input-lg m-bot15">
                                <option>Option 1</option>
                                <option>Option 2</option>
                                <option>Option 3</option>
                            </select>
                            <select class="form-control m-bot15">
                                <option>Option 1</option>
                                <option>Option 2</option>
                                <option>Option 3</option>
                            </select>
                            <select class="form-control input-sm m-bot15">
                                <option>Option 1</option>
                                <option>Option 2</option>
                                <option>Option 3</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
        </section>
        <section class="panel">
            <div class="panel-body">
                <form class="form-horizontal adminex-form" method="get">
                    <div class="form-group has-success">
                        <label class="col-sm-2 control-label col-lg-2" for="inputSuccess">Input with success</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="inputSuccess">
                        </div>
                    </div>
                    <div class="form-group has-warning">
                        <label class="col-sm-2 control-label col-lg-2" for="inputWarning">Input with warning</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="inputWarning">
                        </div>
                    </div>
                    <div class="form-group has-error">
                        <label class="col-sm-2 control-label col-lg-2" for="inputError">Input with error</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" id="inputError">
                        </div>
                    </div>
                </form>
            </div>
        </section>
        <section class="panel">
            <div class="panel-body">
                <form class="form-horizontal adminex-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" for="inputSuccess">Checkboxes and radios</label>
                        <div class="col-lg-10">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" value="">
                                    Option one is this and that&mdash;be sure to include why it's great
                                </label>
                            </div>

                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" value="">
                                    Option one is this and that&mdash;be sure to include why it's great option one
                                </label>
                            </div>

                            <div class="radio">
                                <label>
                                    <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
                                    Option one is this and that&mdash;be sure to include why it's great
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
                                    Option two can be something else and selecting it will deselect option one
                                </label>
                            </div>

                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" for="inputSuccess">Inline checkboxes</label>
                        <div class="col-lg-10">
                            <label class="checkbox-inline">
                                <input type="checkbox" id="inlineCheckbox1" value="option1"> 1
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="inlineCheckbox2" value="option2"> 2
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="inlineCheckbox3" value="option3"> 3
                            </label>

                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" for="inputSuccess">Selects</label>
                        <div class="col-lg-10">
                            <select class="form-control m-bot15">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                            </select>

                            <select multiple class="form-control">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" for="inputSuccess">Column sizing</label>
                        <div class="col-lg-10">
                            <div class="row">
                                <div class="col-lg-2">
                                    <input type="text" class="form-control" placeholder=".col-lg-2">
                                </div>
                                <div class="col-lg-3">
                                    <input type="text" class="form-control" placeholder=".col-lg-3">
                                </div>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" placeholder=".col-lg-4">
                                </div>
                            </div>

                        </div>
                    </div>

                </form>
            </div>
        </section>
        <section class="panel">
            <header class="panel-heading">
                Input groups
            </header>
            <div class="panel-body">
                <form class="form-horizontal adminex-form" method="get">
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" >Basic examples</label>
                        <div class="col-lg-10">
                            <div class="input-group m-bot15">
                                <span class="input-group-addon">@</span>
                                <input type="text" class="form-control" placeholder="Username">
                            </div>

                            <div class="input-group m-bot15">
                                <input type="text" class="form-control">
                                <span class="input-group-addon">.00</span>
                            </div>

                            <div class="input-group m-bot15">
                                <span class="input-group-addon">$</span>
                                <input type="text" class="form-control">
                                <span class="input-group-addon ">.00</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" >Sizing</label>
                        <div class="col-lg-10">
                            <div class="input-group input-group-lg m-bot15">
                                <span class="input-group-addon">@</span>
                                <input type="text" class="form-control input-lg" placeholder="Username">
                            </div>

                            <div class="input-group m-bot15">
                                <span class="input-group-addon">@</span>
                                <input type="text" class="form-control" placeholder="Username">
                            </div>

                            <div class="input-group input-group-sm m-bot15">
                                <span class="input-group-addon">@</span>
                                <input type="text" class="form-control" placeholder="Username">
                            </div>

                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" >Checkboxe and radio</label>
                        <div class="col-lg-10">
                            <div class="input-group m-bot15">
                                              <span class="input-group-addon">
                                                <input type="checkbox">
                                              </span>
                                <input type="text" class="form-control">
                            </div>

                            <div class="input-group m-bot15">
                                              <span class="input-group-addon">
                                                <input type="radio">
                                              </span>
                                <input type="text" class="form-control">
                            </div>

                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" >Button addons</label>
                        <div class="col-lg-10">
                            <div class="input-group m-bot15">
                                              <span class="input-group-btn">
                                                <button class="btn btn-default" type="button">Go!</button>
                                              </span>
                                <input type="text" class="form-control">
                            </div>

                            <div class="input-group m-bot15">
                                <input type="text" class="form-control">
                                              <span class="input-group-btn">
                                                <button class="btn btn-default" type="button">Go!</button>
                                              </span>
                            </div>

                            <div class="input-group m-bot15">
                                <div class="input-group-btn">
                                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>
                                        <li><a href="#">Something else here</a></li>
                                        <li class="divider"></li>
                                        <li><a href="#">Separated link</a></li>
                                    </ul>
                                </div>
                                <input type="text" class="form-control">
                            </div>
                            <div class="input-group m-bot15">
                                <input type="text" class="form-control">
                                <div class="input-group-btn">
                                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>
                                        <li><a href="#">Something else here</a></li>
                                        <li class="divider"></li>
                                        <li><a href="#">Separated link</a></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label col-lg-2" >Segmented buttons</label>
                        <div class="col-lg-10">
                            <div class="input-group m-bot15">
                                <div class="input-group-btn">
                                    <button tabindex="-1" class="btn btn-default" type="button">Action</button>
                                    <button tabindex="-1" data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button">
                                        <span class="caret"></span>
                                    </button>
                                    <ul role="menu" class="dropdown-menu">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>
                                        <li><a href="#">Something else here</a></li>
                                        <li class="divider"></li>
                                        <li><a href="#">Separated link</a></li>
                                    </ul>
                                </div>
                                <input type="text" class="form-control">
                            </div>

                            <div class="input-group m-bot15">
                                <input type="text" class="form-control">
                                <div class="input-group-btn">
                                    <button tabindex="-1" class="btn btn-default" type="button">Action</button>
                                    <button tabindex="-1" data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button">
                                        <span class="caret"></span>
                                    </button>
                                    <ul role="menu" class="dropdown-menu pull-right">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>
                                        <li><a href="#">Something else here</a></li>
                                        <li class="divider"></li>
                                        <li><a href="#">Separated link</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </section>
        <section class="panel">
            <header class="panel-heading">
                Textarea
            </header>
            <div class="panel-body">
                <form method="get" class="form-horizontal bucket-form">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Textarea label</label>
                        <div class="col-sm-10">
                            <textarea rows="6" class="form-control"></textarea>
                        </div>
                    </div>
                </form>
            </div>
        </section>
        </div>
        </div>
        <div class="row">
            <div class="col-md-12">

                <div class="panel" data-collapsed="0">

                    <div class="panel-heading">
                        <div class="panel-title">
                            Input Grid
                        </div>
                    </div>

                    <div class="panel-body">

                        <div class="row">

                            <div class="col-md-12 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-12">
                            </div>

                            <div class="col-md-6 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-6">
                            </div>

                            <div class="col-md-6 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-6">
                            </div>


                            <div class="col-md-4 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-4">
                            </div>

                            <div class="col-md-4 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-4">
                            </div>

                            <div class="col-md-4 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-4">
                            </div>


                            <div class="col-md-3 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-3">
                            </div>

                            <div class="col-md-3 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-3">
                            </div>

                            <div class="col-md-3 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-3">
                            </div>

                            <div class="col-md-3 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-3">
                            </div>


                            <div class="col-md-2 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>


                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1 form-group">
                                <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </div>
		
		<h1>Form Validation</h1>
		      <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Basic validations
                        </header>
                        <div class="panel-body">
                            <form role="form" class="form-horizontal adminex-form">
                                <div class="form-group has-success">
                                    <label class="col-lg-2 control-label">First Name</label>
                                    <div class="col-lg-10">
                                        <input type="text" placeholder="" id="f-name" class="form-control">
                                        <p class="help-block">Successfully done</p>
                                    </div>
                                </div>
                                <div class="form-group has-error">
                                    <label class="col-lg-2 control-label">Last Name</label>
                                    <div class="col-lg-10">
                                        <input type="text" placeholder="" id="l-name" class="form-control">
                                        <p class="help-block">Aha you gave a wrong info</p>
                                    </div>
                                </div>
                                <div class="form-group has-warning">
                                    <label class="col-lg-2 control-label">Email</label>
                                    <div class="col-lg-10">
                                        <input type="email" placeholder="" id="email2" class="form-control">
                                        <p class="help-block">Something went wrong</p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-primary" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Form validations
                        </header>
                        <div class="panel-body">
                            <div class=" form">
                                <form class="cmxform form-horizontal adminex-form" id="commentForm" method="get" action="">
                                    <div class="form-group ">
                                        <label for="cname" class="control-label col-lg-2">Name (required)</label>
                                        <div class="col-lg-10">
                                            <input class=" form-control" id="cname" name="name" minlength="2" type="text" required />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="cemail" class="control-label col-lg-2">E-Mail (required)</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="cemail" type="email" name="email" required />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="curl" class="control-label col-lg-2">URL (optional)</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="curl" type="url" name="url" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="ccomment" class="control-label col-lg-2">Your Comment (required)</label>
                                        <div class="col-lg-10">
                                            <textarea class="form-control " id="ccomment" name="comment" required></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-offset-2 col-lg-10">
                                            <button class="btn btn-primary" type="submit">Save</button>
                                            <button class="btn btn-default" type="button">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </section>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Advanced Form validations
                        </header>
                        <div class="panel-body">
                            <div class="form">
                                <form class="cmxform form-horizontal adminex-form" id="signupForm" method="get" action="">
                                    <div class="form-group ">
                                        <label for="firstname" class="control-label col-lg-2">Firstname</label>
                                        <div class="col-lg-10">
                                            <input class=" form-control" id="firstname" name="firstname" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="lastname" class="control-label col-lg-2">Lastname</label>
                                        <div class="col-lg-10">
                                            <input class=" form-control" id="lastname" name="lastname" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="username" class="control-label col-lg-2">Username</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="username" name="username" type="text" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="password" class="control-label col-lg-2">Password</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="password" name="password" type="password" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="confirm_password" class="control-label col-lg-2">Confirm Password</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="confirm_password" name="confirm_password" type="password" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="email" class="control-label col-lg-2">Email</label>
                                        <div class="col-lg-10">
                                            <input class="form-control " id="email" name="email" type="email" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="agree" class="control-label col-lg-2 col-sm-3">Agree to Our Policy</label>
                                        <div class="col-lg-10 col-sm-9">
                                            <input  type="checkbox" style="width: 20px" class="checkbox form-control" id="agree" name="agree" />
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="newsletter" class="control-label col-lg-2 col-sm-3">Receive the Newsletter</label>
                                        <div class="col-lg-10 col-sm-9">
                                            <input  type="checkbox" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter" />
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-lg-offset-2 col-lg-10">
                                            <button class="btn btn-primary" type="submit">Save</button>
                                            <button class="btn btn-default" type="button">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
			
			
			     <div class="row">
                <div class="col-md-12">
                    <div class="square-widget">
                        <div class="widget-container">
                            <div class="stepy-tab">
                            </div>
                            <form id="default" class="form-horizontal">
                                <fieldset title="Initial Info">
                                    <legend>Personal Information</legend>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Full Name</label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" placeholder="Full Name" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Email Address</label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" placeholder="Email Address" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">User Name</label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" placeholder="Username" class="form-control">
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset title="Contact Info">
                                    <legend>Contact Details</legend>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Phone</label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" placeholder="Phone" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Mobile</label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" placeholder="Mobile" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Address</label>
                                        <div class="col-md-6 col-sm-6">
                                            <textarea rows="5" cols="60" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset title="Billing Details">
                                    <legend>Billing Details</legend>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Billing Name 1</label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" placeholder="Billing Name 1" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Billing Name 2</label>
                                        <div class="col-md-6 col-sm-6">
                                            <input type="text" placeholder="Billing Name 2" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 col-sm-2 control-label">Status</label>
                                        <div class="col-md-6 col-sm-6">
                                            <textarea rows="5" cols="60" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset title="Final Step">
                                    <legend>Final Step Information</legend>
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <p>Congratulations This is the Final Step</p>
                                        </div>
                                    </div>
                                </fieldset>
                                <button class="btn btn-info finish">
                                    Finish </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h4 class="fw-title">Form Wizard with Validation</h4>
                    <div class="box-widget">
                        <div class="widget-head clearfix">
                            <div id="top_tabby" class="block-tabby pull-left">
                            </div>
                        </div>
                        <div class="widget-container">
                            <div class="widget-block">
                                <div class="widget-content box-padding">
                                    <form id="stepy_form" class=" form-horizontal left-align form-well">
                                        <fieldset title="Step 1">
                                            <legend>description one</legend>
                                            <div class="form-group">
                                                <label class="col-md-2 col-sm-2 control-label">Username</label>
                                                <div class="col-md-6 col-sm-6">
                                                    <input class="form-control" name="name" type="text"/>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 col-sm-2 control-label">Email Address</label>
                                                <div class="col-md-6 col-sm-6">
                                                    <input class="form-control" name="email" type="email"/>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset title="Step 2">
                                            <legend>description two</legend>
                                            <div class="form-group">
                                                <label class="col-md-2 col-sm-2 control-label">First Name</label>
                                                <div class="col-md-6 col-sm-6">
                                                    <input type="text" placeholder="First Name" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 col-sm-2 control-label">Last Name</label>
                                                <div class="col-md-6 col-sm-6">
                                                    <input type="text" placeholder="Last Name" class="form-control">
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset title="Step 3">
                                            <legend>description three</legend>
                                            <div class="form-group">
                                                <label class="col-md-2 col-sm-2 control-label">Text Input</label>
                                                <div class="col-md-6 col-sm-6">
                                                    <input type="text" placeholder="Text Input" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 col-sm-2 control-label">Checkbox</label>
                                                <div class="col-md-6 col-sm-6">
                                                    <label class="checkbox">
                                                        <input type="checkbox" value="">
                                                        Option one is this and that—be sure to include why it's great </label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 col-sm-2 control-label">Radio</label>
                                                <div class="col-md-6 col-sm-6">
                                                    <label class="radio">
                                                        <input type="radio" name="optionsRadios" value="option1" checked>
                                                        Option one is this and that—be sure to include why it's great </label>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <button type="submit" class="finish btn btn-info btn-extend"> Finish!</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			<h1>EDITORS </h1>
			
			  <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            CKEditor
                            <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <div class="form">
                                <form action="#" class="form-horizontal">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <textarea class="form-control ckeditor" name="editor1" rows="6"></textarea>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            WYSIWYG Editors
                             <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal ">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <textarea class="wysihtml5 form-control" rows="9"></textarea>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
			
			  <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            WYSIWYG Editors
                             <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal ">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <textarea class="wysihtml5 form-control" rows="9"></textarea>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
			
			  <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            WYSIWYG Editors
                             <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal ">
                                <div class="form-group">
                                    <div class="col-md-12">
                                     <textarea id="editor"  rows="9"></textarea>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
			
			<h1>GALLERY</h1>
			      <div class="row">
                <div class="col-sm-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Media Manager
                            <span class="tools pull-right">
                                <a href="javascript:;" class="fa fa-chevron-down"></a>
                                <a href="javascript:;" class="fa fa-times"></a>
                             </span>
                        </header>
                        <div class="panel-body">

                            <ul id="filters" class="media-filter">
                                <li><a href="#" data-filter="*"> All</a></li>
                                <li><a href="#" data-filter=".images">Images</a></li>
                                <li><a href="#" data-filter=".audio">Audio</a></li>
                                <li><a href="#" data-filter=".video">Video</a></li>
                                <li><a href="#" data-filter=".documents">Documents</a></li>
                            </ul>

                            <div class="btn-group pull-right">
                                <button type="button" class="btn btn-primary btn-sm"><i class="fa fa-check-square-o"></i> Select all</button>
                                <button type="button" class="btn btn-primary btn-sm"><i class="fa fa-folder-open"></i> Add New</button>
                                <button type="button" class="btn btn-primary btn-sm"><i class="fa fa-trash-o"></i> Delete</button>
                                <button type="button" class="btn btn-primary btn-sm"><i class="fa fa-upload"></i> Upload New File</button>
                            </div>



                            <div id="gallery" class="media-gal">
                                <div class="images item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image1.jpg" alt="" />
                                    </a>
                                    <p>img01.jpg </p>
                                </div>

                                <div class=" audio item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image2.jpg" alt="" />
                                    </a>
                                    <p>img02.jpg </p>
                                </div>

                                <div class=" video item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image3.jpg" alt="" />
                                    </a>
                                    <p>img03.jpg </p>
                                </div>

                                <div class=" images audio item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image4.jpg" alt="" />
                                    </a>
                                    <p>img04.jpg </p>
                                </div>

                                <div class=" images documents item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image5.jpg" alt="" />
                                    </a>
                                    <p>img05.jpg </p>
                                </div>

                                <div class=" audio item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image1.jpg" alt="" />
                                    </a>
                                    <p>img01.jpg </p>
                                </div>

                                <div class=" documents item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image2.jpg" alt="" />
                                    </a>
                                    <p>img02.jpg </p>
                                </div>
                                <div class=" video item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image3.jpg" alt="" />
                                    </a>
                                    <p>img03.jpg </p>
                                </div>

                                <div class=" images item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image4.jpg" alt="" />
                                    </a>
                                    <p>img04.jpg </p>
                                </div>

                                <div class=" documents item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image5.jpg" alt="" />
                                    </a>
                                    <p>img05.jpg </p>
                                </div>

                                <div class=" video item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image1.jpg" alt="" />
                                    </a>
                                    <p>img01.jpg </p>
                                </div>

                                <div class=" audio images item " >
                                    <a href="#myModal" data-toggle="modal">
                                        <img src="images/gallery/image2.jpg" alt="" />
                                    </a>
                                    <p>img02.jpg </p>
                                </div>

                            </div>

                            <div class="col-md-12 text-center clearfix">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">Edit Media Gallery</h4>
                                        </div>

                                        <div class="modal-body row">

                                            <div class="col-md-5 img-modal">
                                                <img src="images/gallery/image1.jpg" alt="">
                                                <a href="#" class="btn btn-white btn-sm"><i class="fa fa-pencil"></i> Edit Image</a>
                                                <a href="#" class="btn btn-white btn-sm"><i class="fa fa-eye"></i> View Full Size</a>

                                                <p class="mtop10"><strong>File Name:</strong> img01.jpg</p>
                                                <p><strong>File Type:</strong> jpg</p>
                                                <p><strong>Resolution:</strong> 300x200</p>
                                                <p><strong>Uploaded By:</strong> <a href="#">ThemeBucket</a></p>
                                            </div>
                                            <div class="col-md-7">
                                                <div class="form-group">
                                                    <label> Name</label>
                                                    <input id="name" value="img01.jpg" class="form-control">
                                                </div>
                                                <div class="form-group">
                                                    <label> Tittle Text</label>
                                                    <input id="title" value="awesome image" class="form-control">
                                                </div>
                                                <div class="form-group">
                                                    <label> Description</label>
                                                    <textarea rows="2" class="form-control"></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label> Link URL</label>
                                                    <input id="link" value="images/gallery/img01.jpg" class="form-control">
                                                </div>
                                                <div class="pull-right">
                                                    <button class="btn btn-danger btn-sm" type="button">Delete</button>
                                                    <button class="btn btn-success btn-sm" type="button">Save changes</button>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- modal -->

                        </div>
                    </section>
                </div>
            </div>
			
			<div class="row">
			  <section class="panel">
                <header class="panel-heading">
                    Dropzone File Upload
                    <span class="tools pull-right">
                        <a class="fa fa-chevron-down" href="javascript:;"></a>
                        <a class="fa fa-times" href="javascript:;"></a>
                     </span>
                </header>
                <div class="panel-body">
                    <form action="js/dropzone/upload.php" class="dropzone" id="my-awesome-dropzone"></form>
                </div>
            </section>
			</div>
			
			<h1>PICKERS</h1>
			    <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Date Pickers
                              <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <form action="#" class="form-horizontal ">

                                <div class="form-group">
                                    <label class="control-label col-md-3">Default Datepicker</label>
                                    <div class="col-md-4 col-xs-11">
                                        <input class="form-control form-control-inline input-medium default-date-picker"  size="16" type="text" value="" />
                                        <span class="help-block">Select date</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Start with years viewMode</label>
                                    <div class="col-md-4 col-xs-11">

                                        <div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="12-02-2012"  class="input-append date dpYears">
                                            <input type="text" readonly="" value="12-02-2012" size="16" class="form-control">
                                                          <span class="input-group-btn add-on">
                                                            <button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
                                                          </span>
                                        </div>
                                        <span class="help-block">Select date</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Months Only</label>
                                    <div class="col-md-4 col-xs-11">
                                        <div data-date-minviewmode="months" data-date-viewmode="years" data-date-format="mm/yyyy" data-date="102/2012"  class="input-append date dpMonths">
                                            <input type="text" readonly="" value="02/2012" size="16" class="form-control">
                                                          <span class="input-group-btn add-on">
                                                            <button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
                                                          </span>
                                        </div>


                                        <span class="help-block">Select month only</span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Date Range</label>
                                    <div class="col-md-4">
                                        <div class="input-group input-large custom-date-range" data-date="13/07/2013" data-date-format="mm/dd/yyyy">
                                            <input type="text" class="form-control dpd1" name="from">
                                            <span class="input-group-addon">To</span>
                                            <input type="text" class="form-control dpd2" name="to">
                                        </div>
                                        <span class="help-block">Select date range</span>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </section>
                </div>
                <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-body">
                            <a class="btn btn-primary" data-toggle="modal" href="#myModal2">
                                Datepicker in Modal
                            </a>
                            <!-- Modal -->
                            <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">Datepicker in Modal</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form action="#" class="form-horizontal ">
                                                <div class="form-group">
                                                    <label class="control-label col-md-4"> Date time picker</label>
                                                    <div class="col-md-6">
                                                        <input size="16" type="text" value="2012-06-15 14:45" readonly class="form_datetime form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="control-label col-md-4">Default Datepicker</label>
                                                    <div class="col-md-6 col-xs-11">
                                                        <input class="form-control form-control-inline input-medium default-date-picker"  size="16" type="text" value="" />
                                                        <span class="help-block">Select date</span>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="control-label col-md-4">Start with years viewMode</label>
                                                    <div class="col-md-6 col-xs-11">

                                                        <div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="12-02-2012"  class="input-append date dpYears">
                                                            <input type="text" readonly="" value="12-02-2012" size="16" class="form-control">
                                                                      <span class="input-group-btn add-on">
                                                                        <button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
                                                                      </span>
                                                        </div>
                                                        <span class="help-block">Select date</span>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-4">Months Only</label>
                                                    <div class="col-md-6 col-xs-11">
                                                        <div data-date-minviewmode="months" data-date-viewmode="years" data-date-format="mm/yyyy" data-date="102/2012"  class="input-append date dpMonths">
                                                            <input type="text" readonly="" value="02/2012" size="16" class="form-control">
                                                                      <span class="input-group-btn add-on">
                                                                        <button class="btn btn-primary" type="button"><i class="fa fa-calendar"></i></button>
                                                                      </span>
                                                        </div>


                                                        <span class="help-block">Select month only</span>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-md-4">Date Range</label>
                                                    <div class="col-md-6">
                                                        <div class="input-group input-large custom-date-range" data-date="13/07/2013" data-date-format="mm/dd/yyyy">
                                                            <input type="text" class="form-control dpd1" name="from">
                                                            <span class="input-group-addon">To</span>
                                                            <input type="text" class="form-control dpd2" name="to">
                                                        </div>
                                                        <span class="help-block">Select date range</span>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>


                                        <form class="form-horizontal  " action="#">
                                            <div class="form-group">
                                                <label class="control-label col-md-4">Default Timepicker</label>
                                                <div class="col-md-6">
                                                    <div class="input-group bootstrap-timepicker">
                                                        <input type="text" class="form-control timepicker-default">
                                                            <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button"><i class="fa fa-clock-o"></i></button>
                                                            </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-4">24hr Timepicker</label>
                                                <div class="col-md-6">
                                                    <div class="input-group bootstrap-timepicker">
                                                        <input type="text" class="form-control timepicker-24">
                                                            <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button"><i class="fa fa-clock-o"></i></button>
                                                            </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>



                                        <div class="modal-footer">
                                            <button data-dismiss="modal" class="btn btn-primary" type="button">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- modal -->
                        </div>
                    </section>
                </div>
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Datetime Pickers
                             <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal  " action="#">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Default input Datetimepicker</label>
                                    <div class="col-md-4">
                                        <input size="16" type="text" value="2012-06-15 14:45" readonly class="form_datetime form-control">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3"> Component Datetimepicker</label>
                                    <div class="col-md-4">
                                        <div class="input-group date form_datetime-component">
                                            <input type="text" class="form-control" readonly="" size="16">
                                                            <span class="input-group-btn">
                                                            <button type="button" class="btn btn-primary date-set"><i class="fa fa-calendar"></i></button>
                                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Advance Datetimepicker</label>
                                    <div class="col-md-4">
                                        <div data-date="2012-12-21T15:25:00Z" class="input-group date form_datetime-adv">
                                            <input type="text" class="form-control" readonly="" size="16">
                                            <div class="input-group-btn">
                                                <button type="button" class="btn btn-primary date-reset"><i class="fa fa-times"></i></button>
                                                <button type="button" class="btn btn-success date-set"><i class="fa fa-calendar"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Meridian Format</label>
                                    <div class="col-md-4">
                                        <div data-date="2012-12-21T15:25:00Z" class="input-group date form_datetime-meridian">
                                            <input type="text" class="form-control" readonly="" size="16">
                                            <div class="input-group-btn">
                                                <button type="button" class="btn btn-primary date-reset"><i class="fa fa-times"></i></button>
                                                <button type="button" class="btn btn-success date-set"><i class="fa fa-calendar"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                            </form>
                        </div>
                    </section>
                </div>
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Time Pickers
                             <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal  " action="#">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Default Timepicker</label>
                                    <div class="col-md-4">
                                        <div class="input-group bootstrap-timepicker">
                                            <input type="text" class="form-control timepicker-default">
                                                            <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button"><i class="fa fa-clock-o"></i></button>
                                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">24hr Timepicker</label>
                                    <div class="col-md-4">
                                        <div class="input-group bootstrap-timepicker">
                                            <input type="text" class="form-control timepicker-24">
                                                            <span class="input-group-btn">
                                                            <button class="btn btn-default" type="button"><i class="fa fa-clock-o"></i></button>
                                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
                <div class="col-md-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Color Pickers
                            <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                                <a class="fa fa-times" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <form class="form-horizontal  " action="#">
                                <div class="form-group">
                                    <label class="control-label col-md-3">Default</label>
                                    <div class="col-md-4">
                                        <input type="text" class="colorpicker-default form-control" value="#8fff00" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">RGBA</label>
                                    <div class="col-md-4">
                                        <input type="text" class="colorpicker-rgba form-control" value="rgb(0,194,255,0.78)" data-color-format="rgba" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">As Component</label>
                                    <div class="col-md-4 col-xs-11">
                                        <div data-color-format="rgb" data-color="rgb(255, 146, 180)" class="input-append colorpicker-default color">
                                            <input type="text" readonly="" value="" class="form-control">
                                              <span class=" input-group-btn add-on">
                                                  <button class="btn btn-default" type="button" style="padding: 8px">
                                                      <i style="background-color: rgb(124, 66, 84);"></i>
                                                  </button>
                                              </span>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
			
			<h1>Calender</h1>
			  <div class="row">
                <aside class="col-md-3">
                    <h4 class="drg-event-title"> Draggable Events</h4>
                    <div id='external-events'>
                        <div class='external-event label label-primary'>My Event 1</div>
                        <div class='external-event label label-success'>My Event 2</div>
                        <div class='external-event label label-info'>My Event 3</div>
                        <div class='external-event label label-primary'>My Event 4</div>
                        <div class='external-event label label-warning'>My Event 5</div>
                        <div class='external-event label label-danger'>My Event 6</div>
                        <div class='external-event label label-default'>My Event 7</div>
                        <div class='external-event label label-primary'>My Event 8</div>
                        <div class='external-event label label-info'>My Event 9</div>
                        <div class='external-event label label-success'>My Event 10</div>
                        <p class="border-top drp-rmv">
                            <input type='checkbox' id='drop-remove' />
                            Remove after drop
                        </p>
                        <br/>
                    </div>
                </aside>
                <aside class="col-md-9">
                    <section class="panel">
                        <div id="calendar" class="has-toolbar"></div>
                    </section>
                </aside>

            </div>
			
			
			
        </div>
        <!--body wrapper end-->

        <!--footer section start-->
        <footer>
            2014 &copy; AdminEx by ThemeBucket
        </footer>
        <!--footer section end-->


    </div>
    <!-- main content end-->
</section>

<?php include("templates/footer.php"); ?>
</body>
</html>
