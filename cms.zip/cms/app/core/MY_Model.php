<?php

class MY_Model extends CI_Model {

    protected $_table_name = ""; 
	protected $_primary_key = "id"; 
	protected $_primary_filter = "intval"; 
	protected $_order_by = ""; 
	public  $_rules = array(); 
	protected $_timestamps = FALSE; 


	public function __construct()
    {
        parent::__construct(); 
    }

//general get data from database
    public function get($id = NULL,$single = FALSE){
    	
          $table = $this->_table_name; 
    	if($id != NULL)
    	{
          $filter = $this->_primary_filter;
          $id = $filter($id);
          $key = $this->_primary_key;

          $sql = "SELECT * FROM  $table  WHERE $key = $id";
          $query = $this->db->query($sql);
          return $query->row();
    	}
    	elseif ($single == TRUE) {
    	  $sql = "SELECT * FROM $table WHERE $key = $id";
          $query = $this->db->query($sql);
          return $query->row();
    	}
    		else
    	{
           $sql = "SELECT * FROM  $table ";
    		$query = $this->db->query($sql);
            return $query->result();
    	}
     $this->db->order_by($this->_order_by);

    return $this->db->get($this->_table_name)->$method; 
 
    }

    public function get_by($where)
    {
         $table = $this->_table_name; 	
    	return   $this->db->get_where($table, $where)->result();
    }

    public function save($data , $id = NULL)
    {
    	 $table = $this->_table_name; 
        if($id === NULL)
        {
           if(!isset($data[$this->_primary_key]) || $data[$this->_primary_key] = NULL)
           {
           	$this->db->insert($table, $data);
            $id = $this->db->insert_id();
           }
        }
        else
        {
          $filter = $this->_primary_filter;
          $id = $filter($id);
          $key = $this->_primary_key;
          $this->db->where($key, $id);
          $this->db->update($table, $data); 
        }

        return $id;
    }

    public function delete($id){
    	if(!$id)
    	{return FALSE; }
    {
    	$key = $this->_primary_key;
    	$table = $this->_table_name;
    	$this->db->where($key, $id);
        $this->db->delete($table); 
        return TRUE;
    }
    }
}
