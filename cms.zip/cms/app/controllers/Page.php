<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends Frontend_Controller {

	function __construct()
		{
		parent::__construct(); 
		$this->load->model('Page_M');
		}

	public function index()
	{
		$pages = $this->Page_M->get_by(array('slug' => 'about'));
		var_dump($pages);
		
	}

	public function save()
	{
		$data = array(
			'order' =>'4',
			'body' =>"Lorem Ipsum is simply dummy" ,
			          );
		$pages = $this->Page_M->delete(3);
		var_dump($pages);
		
	}

}
