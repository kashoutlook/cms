<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends Admin_Controller {
	public function __construct()
	{
		parent::__construct();
	}
	
	public function index()
	{
		$head_info = array('title' => 'Dashboard');
		$data = array(
				'head_info' => $head_info,
		);
		$this->load->view('admin/dashboard',$data);
	}
	
	public function modal()
	{
		$this->load->view('admin/modal_layout');
	}
}
