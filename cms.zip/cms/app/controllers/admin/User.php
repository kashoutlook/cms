<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends Admin_Controller {

	//controller
	public function __construct()
	{
		parent::__construct();
		
	}
	public function index()
	{
		$rules  = $this->user_M->_rules;
		$head_info = array('title' => 'Login');
		$subviews = array('subview' => "admin/user/login");
		
		$data = array(
				'head_info'  =>  $head_info,
				'subview'  =>  $subviews,
		);
		$this->load->view('admin/layout_modal',$data);
	}
	public function login()
	{
		$this->form_validation->set_rules('username', 'Username OR Email', 'trim|required|min_length[2]|max_length[60]',array('required' => 'You must provide a %s.'));
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[2]',array('required' => 'You must provide a %s.'));
		
		if ($this->form_validation->run() == FALSE)
		{
			$rules  = $this->user_M->_rules;
		$head_info = array('title' => 'Login');
		$subviews = array('subview' => "admin/user/login");
		
		$data = array(
				'head_info'  =>  $head_info,
				'subview'  =>  $subviews,
		);
		$this->load->view('admin/layout_modal',$data);
		}
		else
		{
			        $username = $this->input->post('username');
                	$password = $this->input->post('password');
                	
                	if($this->user_M->check_email_username($username))
                	{
                		if($this->user_M->check_user_active_status($username))
                		{
                			if($this->user_M->check_that_password($username,$password))
                			{
                				 
                				redirect('profile');
                					
                			}
                			else
                			{
                				$this->session->set_flashdata('login_error3','Wrong Password Entered');
                				redirect('admin/user/login');
                			}
                		}
                		else
                		{
                			$this->session->set_flashdata('login_error2','Your Account is not activated.');
                			redirect('admin/user/login');
                		}
                	}
                	else 
                	{
                		$this->session->set_flashdata('login_error1','Your Have entered the wrong username of Email');
                		redirect('admin/user/login');
                	}
		}
	}
}
